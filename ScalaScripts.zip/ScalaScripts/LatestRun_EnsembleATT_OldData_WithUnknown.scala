// Read all data
var temp11 = spark.read.format("org.apache.spark.sql.execution.datasources.parquet.ParquetFileFormat").load("/data/etl_combine/latest_run/att_extracted_filtered")

//// Read new data
//var newdata = spark.read.format("org.apache.spark.sql.execution.datasources.parquet.ParquetFileFormat").load("/data/etl_combine/latest_run/NewlyExtractedData/")
//newdata = newdata.select("document","index","label", "title", "content", "md5String", "requestid", "concept", "final_concept")
//// Combine both
//temp11 = temp11.union(newdata)
// 
//// Read overlap data and filter all data according to it
//var overlap = spark.read.format("org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").option(
//    "inferSchema","true").load("/data/etl_combine/latest_run/final_dataset_160k_no_concepts.csv")
//overlap = overlap.drop("_c0")
//temp11 = temp11.join(overlap.drop("label"),"document")
//temp11 = temp11.filter("overlap <= 2")

//var topicsToDrop = Array(1,2,3,4,11,13,15,19,20,23,28,30,31,38,45,53,55,59,61,72,75,79,82,83,84,85,87,91,93,94,99,100).map(x=>x-1)
//var temp11_filter = temp11.filter($"topic_id" not in (0, 1, 2, 3, 10, 12, 14, 18, 19, 22, 27, 29, 30, 37, 44, 52, 54, 58, 60, 71, 74, 78, 81, 82, 83, 84, 86, 90, 92, 93, 98, 99))

// Read golden dataset
var gold = spark.read.format("org.apache.spark.sql.execution.datasources.parquet.ParquetFileFormat").load("/data/etl_combine/production_output/Run1/label_si_out")
gold.createOrReplaceTempView("goldView")
//temp11 = temp11.where("document NOT IN (SELECT document FROM goldView)")
//
//val fractions = temp11.select("label").distinct.rdd.keyBy(_.getString(0)).map(_._1).map(x=>(x,0.8)).collectAsMap.toMap
//var train_df = temp11.stat.sampleBy("label",fractions,36L)
//var test_df = temp11.except(train_df)

var test_df = gold
var train_df = temp11.where("document NOT IN (SELECT document FROM goldView)")
//var train_df = temp11.except(test_df)

// Filter for top 50 categories
//var n = 50
//var top_n = temp11.groupBy("label").count.sort($"count".desc).limit(n)
//top_n.createOrReplaceTempView("top_n_view")
//train_df = train_df.where("label IN (SELECT label from top_n_view)")
//test_df = test_df.where("label IN (SELECT label from top_n_view)")

//gold = gold.filter("label not in ('Health and Fitness_Infertility', 'Technology and Computing_Unix')")

// Filter for those particular 15 Categories
import org.apache.spark.sql.functions._

val labels_to_retain = List("Adult Content_UNKNOWN", "Arts and Entertainment_Television", "Arts and Entertainment_Music", "Arts and Entertainment_Celebrity Fan/Gossip",
    "Careers_Job Search","Hobbies and Interests_Freelance Writing", "Hobbies and Interests_Video & Computer Games", "News_UNKNOWN", "Real Estate_Buying/Selling Homes", "Shopping_Engines",
    "Society_Dating", "Style and Fashion_Clothing", "Sports_Football", "Technology and Computing_Internet Technology", "Technology and Computing_Web Search")
    
var modifyLabel = udf((label:String) => if(labels_to_retain.contains(label)) label else "Others")

train_df = train_df.withColumn("label_modified",modifyLabel(col("label")))
train_df = train_df.drop("label").withColumnRenamed("label_modified","label")
test_df = test_df.withColumn("label_modified",modifyLabel(col("label")))
test_df = test_df.drop("label").withColumnRenamed("label_modified","label")

train_df = train_df.filter("label not in ('Others')")


////
train_df.createOrReplaceTempView("trainView")
test_df.createOrReplaceTempView("testView")
////

train_df = train_df.where("document NOT IN (SELECT document from testView)")

//// Change label distribution of train_df according to the label distribution of test_df
//var tr = train_df.groupBy("label").count.sort($"count".desc).toDF("label","count_train")
//var te = test_df.groupBy("label").count.sort($"count".desc).toDF("label","count_test")
//var tr_te = tr.join(te,"label")
//tr_te = tr_te.withColumn("tr_by_test",$"count_train"/$"count_test")
//var min_factor = tr_te.agg(min("tr_by_test")).select("min(tr_by_test)").collectAsList().get(0).getDouble(0)
//min_factor = math.ceil(min_factor).toInt
//tr_te = tr_te.withColumn("count_train_required",$"count_test"*min_factor)
////counttr_te_req = tr_te.withColumn("count_required_int", tr_te("count_required").cast(IntegerType)).drop("count_required")
//tr_te = tr_te.withColumn("prob",$"count_train_required"/$"count_train")
//import org.apache.spark.sql.functions._
//train_df = train_df.join(tr_te,"label").withColumn("rand",rand()).where($"rand"<$"prob")

import org.apache.spark.ml.feature.StringIndexer
val indexer = new StringIndexer().setInputCol("label").setOutputCol("categoryIndex")   //setHandleInvalid("keep")
train_df = indexer.fit(train_df).transform(train_df)

val hashingTF = new org.apache.spark.ml.feature.HashingTF().setInputCol("final_concept").setOutputCol("features")
val idf = new org.apache.spark.ml.feature.IDF().setInputCol(hashingTF.getOutputCol).setOutputCol("features_scaled")
val feature_pipe = new org.apache.spark.ml.Pipeline().setStages(Array(hashingTF,idf))
val feature_pipe_model = feature_pipe.fit(train_df)

test_df = feature_pipe_model.transform(test_df)
train_df = feature_pipe_model.transform(train_df)

val naive = new org.apache.spark.ml.classification.NaiveBayes().setLabelCol("categoryIndex").setFeaturesCol(
    "features_scaled").setModelType("multinomial").setPredictionCol("NaiveCategory").setProbabilityCol("NaiveProbability").setRawPredictionCol("NaiveRaw")
val logistic1 = new org.apache.spark.ml.classification.LogisticRegression().setMaxIter(15).setLabelCol(
    "categoryIndex").setFeaturesCol("features_scaled").setPredictionCol("Logic1Category").setFamily("multinomial").setRawPredictionCol("Logic1Raw").setProbabilityCol("Logic1Probability")
val ensembler = new Ensembler()
val train = ensembler.ensembling(Array(logistic1,naive),train_df,"categoryIndex","label",4,"combine_vec")
val train_result = train._1
val max = train._2

val model_result = ensembler.fit(Array(logistic1,naive),train_df)
val test_result = ensembler.predict(Array(logistic1,naive),model_result,test_df,"combine_vec",max)

val logistic = new org.apache.spark.ml.classification.LogisticRegression().setMaxIter(15).setLabelCol(
    "categoryIndex").setFeaturesCol("combine_vec").setPredictionCol("LogicCategory").setFamily("multinomial")
val logistic_model = logistic.fit(train_result)
val predicted_df = logistic_model.transform(test_result)

val indexList = train_df.select("label","categoryIndex").distinct.toDF("predLabel","LogicCategory")
val result = predicted_df.join(indexList,"LogicCategory")
result.select("label","predLabel").rdd.filter(x => x.getString(0).equals(x.getString(1))).count
result.count

predicted_df.select("document","label","LogicCategory").coalesce(1).write.format(
     "org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").save("/data/etl_combine/latest_run/pred_df_df22")
indexList.coalesce(1).write.format(
     "org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").save("/data/etl_combine/latest_run/indexList_df22")
     
     
result.select("document","predLabel","label").coalesce(1).write.format(
    "org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").save("/data/etl_combine/latest_run/result_gold_15_categories_and_Others_new")
//train_df.select("document","correctLabel").coalesce(1).write.format(
//    "org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").save("/data/etl_combine/production_output/Run5_top50_8020/train_8020_prod/")
//test_df.select("document","correctLabel").coalesce(1).write.format(
//    "org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").save("/data/etl_combine/production_output/Run5_top50_8020/test_8020_prod/")


// Append stratified split train-test labels to htf_out data
//var temp_train = train_df.select("document").withColumn("split_index",lit(0))
//var temp_test = test_df.select("document").withColumn("split_index",lit(1))
//var temp = temp_train.union(temp_test)    
//
//result.select("document","predLabel","label").coalesce(1).write.format(
//    "org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").save("/data/etl_combine/latest_run/result_topicfilter_gold_only_15_categories")

//**************Comment below block if not reading those fixed 3K URLS
//////////

// For reading pred_3K and excluding them from gold
//var pred_3k = spark.read.format(
//    "org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").load(
//        "/data/etl_combine/save_predicted_df_3k/part-00000-2c010a9e-7956-4b27-bc40-3507cadac4f0.csv")
//pred_3k.createOrReplaceTempView("predview")
//
//// Train on 12K and test on the 3K URLs present n the pred_3k dataframe
//var test_df = gold.where("document IN (SELECT document FROM predview)")
//var train_df = gold.where("document NOT IN (SELECT document FROM predview)")

///////////