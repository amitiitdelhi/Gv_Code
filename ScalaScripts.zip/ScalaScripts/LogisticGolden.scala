
var golden_df = spark.read.parquet("/data/etl_combine/gold").repartition(48)
golden_df = golden_df.filter("final_concept_count > 0")
var train_df = golden_df.limit((golden_df.count()*0.9).toInt).toDF()
var test_df = golden_df.except(train_df).toDF()
import org.apache.spark.ml.feature.StringIndexer
val indexer = new StringIndexer().setInputCol("label").setOutputCol("categoryIndex")
train_df = indexer.fit(train_df).transform(train_df)
val hashingTF = new org.apache.spark.ml.feature.HashingTF().setInputCol("final_concept").setOutputCol("features")
val idf = new org.apache.spark.ml.feature.IDF().setInputCol(hashingTF.getOutputCol).setOutputCol("features_scaled")
val feature_pipe = new org.apache.spark.ml.Pipeline().setStages(Array(hashingTF,idf))
val feature_pipe_model = feature_pipe.fit(train_df)
val logistic = new org.apache.spark.ml.classification.LogisticRegression().setMaxIter(15).setLabelCol("categoryIndex").setFeaturesCol("features_scaled").setPredictionCol("LogicCategory").setFamily("multinomial").setRawPredictionCol("LogicRaw").setProbabilityCol("LogicProbability")
val logistic_pipe = new org.apache.spark.ml.Pipeline().setStages(Array(feature_pipe_model,logistic))

val logistic_model = logistic_pipe.fit(train_df)

val predicted_df = logistic_model.transform(test_df)

val indexList = train_df.select("label","categoryIndex").distinct.toDF("predLabel","NaiveCategory")
val result = predicted_df.join(indexList,"NaiveCategory")
result.select("label","predLabel").rdd.filter(x => x.getString(0).equals(x.getString(1))).count
result.count




var golden_df = spark.read.parquet("/data/etl_combine/gold").repartition(48)
golden_df = golden_df.filter("final_concept_count > 0")
import org.apache.spark.ml.feature.StringIndexer
val indexer = new StringIndexer().setInputCol("label").setOutputCol("categoryIndex")
golden_df = indexer.fit(golden_df).transform(golden_df)
val hashingTF = new org.apache.spark.ml.feature.HashingTF().setInputCol("final_concept").setOutputCol("features")
val idf = new org.apache.spark.ml.feature.IDF().setInputCol(hashingTF.getOutputCol).setOutputCol("features_scaled")
val feature_pipe = new org.apache.spark.ml.Pipeline().setStages(Array(hashingTF,idf))
val feature_pipe_model = feature_pipe.fit(golden_df)
val logistic = new org.apache.spark.ml.classification.LogisticRegression().setMaxIter(15).setLabelCol("categoryIndex").setFeaturesCol("features_scaled").setPredictionCol("LogicCategory").setFamily("multinomial").setRawPredictionCol("LogicRaw").setProbabilityCol("LogicProbability")
val logistic_pipe = new org.apache.spark.ml.Pipeline().setStages(Array(feature_pipe_model,logistic))
val logistic_model = logistic_pipe.fit(golden_df)
