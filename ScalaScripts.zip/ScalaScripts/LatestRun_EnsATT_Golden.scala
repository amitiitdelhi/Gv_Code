
var train_df = spark.read.format("org.apache.spark.sql.execution.datasources.parquet.ParquetFileFormat").load("/data/etl_combine/latest_run/att_extracted_filtered")

var n = 50
var top_n = train_df.groupBy("label").count.sort($"count".desc).limit(n)
top_n.createOrReplaceTempView("top_n_view")
train_df = train_df.where("label IN (SELECT label from top_n_view)")
//test_df = test_df.where("label IN (SELECT label from top_n_view)")


var js_xml = spark.read.format("org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").option("index","true").load("/data/etl_combine/latest_run/att_invalid_URLs_100K.csv")
js_xml.createOrReplaceTempView("js_xml_view")
train_df = train_df.where("document NOT IN (SELECT document FROM js_xml_view)")


// For human label
var test_df = spark.read.format("org.apache.spark.sql.execution.datasources.parquet.ParquetFileFormat").load("/data/etl_combine/production_output/Run1/label_si_out")
// For Uncat Report
var test_df = spark.read.format("org.apache.spark.sql.execution.datasources.parquet.ParquetFileFormat").load("/data/etl_combine/latest_run/Uncat_500/cf_out/")


////
train_df.createOrReplaceTempView("trainView")
test_df.createOrReplaceTempView("testView")
train_df.where("document IN (SELECT document from testView)").count
test_df.where("document IN (SELECT document from trainView)").count

train_df.select("label").distinct.count
test_df.select("label").distinct.count
train_df.count/test_df.count
////

train_df = train_df.where("document NOT IN (SELECT document from testView)")

import org.apache.spark.ml.feature.StringIndexer
val indexer = new StringIndexer().setInputCol("label").setOutputCol("categoryIndex")   //setHandleInvalid("keep")
train_df = indexer.fit(train_df).transform(train_df)

val hashingTF = new org.apache.spark.ml.feature.HashingTF().setInputCol("final_concept").setOutputCol("features")
val idf = new org.apache.spark.ml.feature.IDF().setInputCol(hashingTF.getOutputCol).setOutputCol("features_scaled")
val feature_pipe = new org.apache.spark.ml.Pipeline().setStages(Array(hashingTF,idf))
val feature_pipe_model = feature_pipe.fit(train_df)

test_df = feature_pipe_model.transform(test_df)
train_df = feature_pipe_model.transform(train_df)

val naive = new org.apache.spark.ml.classification.NaiveBayes().setLabelCol("categoryIndex").setFeaturesCol(
    "features_scaled").setModelType("multinomial").setPredictionCol("NaiveCategory").setProbabilityCol("NaiveProbability").setRawPredictionCol("NaiveRaw")
val logistic1 = new org.apache.spark.ml.classification.LogisticRegression().setMaxIter(15).setLabelCol(
    "categoryIndex").setFeaturesCol("features_scaled").setPredictionCol("Logic1Category").setFamily("multinomial").setRawPredictionCol("Logic1Raw").setProbabilityCol("Logic1Probability")
val ensembler = new Ensembler()
val train = ensembler.ensembling(Array(logistic1,naive),train_df,"categoryIndex","label",4,"combine_vec")
val train_result = train._1
val max = train._2

// train_result.write.parquet("/data/etl_combine/gold_ens_4fold_save/train_result")
// train_df.write.parquet("/data/etl_combine/gold_ens_4fold_save/train_df")
// test_df.write.parquet("/data/etl_combine/gold_ens_4fold_save/test_df")
// max: Int = 289
//var train_result = spark.read.parquet("/data/etl_combine/gold_ens_4fold_save/train_result").repartition(48)
//var train_df = spark.read.parquet("/data/etl_combine/gold_ens_4fold_save/train_df").repartition(48)
//var test_df = spark.read.parquet("/data/etl_combine/gold_ens_4fold_save/test_df").repartition(48)
//var max = 289

val model_result = ensembler.fit(Array(logistic1,naive),train_df)
val test_result = ensembler.predict(Array(logistic1,naive),model_result,test_df,"combine_vec",max)

val logistic = new org.apache.spark.ml.classification.LogisticRegression(
    ).setMaxIter(15).setLabelCol("categoryIndex").setFeaturesCol("combine_vec").setPredictionCol("LogicCategory").setFamily("multinomial")
val logistic_model = logistic.fit(train_result)
val predicted_df = logistic_model.transform(test_result)

val indexList = train_df.select("label","categoryIndex").distinct.toDF("predLabel","LogicCategory")
val result = predicted_df.join(indexList,"LogicCategory")
result.select("label","predLabel").rdd.filter(x => x.getString(0).equals(x.getString(1))).count
result.count

predicted_df.select("document","label","LogicCategory").coalesce(1).write.format(
     "org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").save("/data/etl_combine/latest_run/pred_df_gold")
indexList.coalesce(1).write.format(
     "org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").save("/data/etl_combine/latest_run/indexList_gold")
     
     
result.select("document","correctLabel","predLabel").coalesce(1).write.format(
    "org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").save("/data/etl_combine/production_output/Run5_top50_8020/result_8020_prod/")
train_df.select("document","correctLabel").coalesce(1).write.format(
    "org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").save("/data/etl_combine/production_output/Run5_top50_8020/train_8020_prod/")
test_df.select("document","correctLabel").coalesce(1).write.format(
    "org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").save("/data/etl_combine/production_output/Run5_top50_8020/test_8020_prod/")

    
// Append stratified split train-test labels to htf_out data
var temp_train = train_df.select("document").withColumn("split_index",lit(0))
var temp_test = test_df.select("document").withColumn("split_index",lit(1))
var temp = temp_train.union(temp_test)    

//result.select("document","correctLabel","predLabel","label").toDF("document","HumanLabel","NBLabel","IBlabel"
//    ).coalesce(1).write.format("org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").save("/data/gold_train_test_csv/nb_labels")

//**************Comment below block if not reading those fixed 3K URLS
//////////

// For reading pred_3K and excluding them from gold
//var pred_3k = spark.read.format(
//    "org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").load(
//        "/data/etl_combine/save_predicted_df_3k/part-00000-2c010a9e-7956-4b27-bc40-3507cadac4f0.csv")
//pred_3k.createOrReplaceTempView("predview")
//
//// Train on 12K and test on the 3K URLs present n the pred_3k dataframe
//var test_df = gold.where("document IN (SELECT document FROM predview)")
//var train_df = gold.where("document NOT IN (SELECT document FROM predview)")

///////////
