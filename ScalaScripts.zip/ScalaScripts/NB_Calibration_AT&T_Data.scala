// Sample from the top 2 categories
//gold.groupBy("label").count().sort($"count".desc).show(false)
//var temp = gold.filter("label in ('Arts and Entertainment_Music')").select("document","label","title").limit(10)
//var temp1 = gold.filter("label in ('News_UNKNOWN')").select("document","label","title").limit(5)
//temp = temp.union(temp1)
//val fractions = temp.select("label").distinct.rdd.keyBy(_.getString(0)).map(_._1).map(x=>(x,0.8)).collectAsMap.toMap
//var train = temp.stat.sampleBy("label",fractions,36L)
//var test = temp.except(train)

var train_df = spark.read.parquet("/data/etl_combine/trainData")
train_df = train_df.filter("final_concept_count > 0")
var test_df = spark.read.parquet("/data/etl_combine/testData")
test_df = test_df.filter("final_concept_count > 0")

val fractions = train_df.select("label").distinct.rdd.keyBy(_.getString(0)).map(_._1).map(x=>(x,0.25)).collectAsMap.toMap
var validate_df = train_df.stat.sampleBy("label",fractions,36L)
train_df = train_df.except(validate_df)


import org.apache.spark.ml.feature.StringIndexer
val indexer = new StringIndexer().setInputCol("label").setOutputCol("categoryIndex")
train_df = indexer.setHandleInvalid("skip").fit(train_df).transform(train_df)

val hashingTF = new org.apache.spark.ml.feature.HashingTF().setInputCol("final_concept").setOutputCol("features")
val idf = new org.apache.spark.ml.feature.IDF().setInputCol(hashingTF.getOutputCol).setOutputCol("features_scaled")
val feature_pipe = new org.apache.spark.ml.Pipeline().setStages(Array(hashingTF,idf))
val feature_pipe_model = feature_pipe.fit(train_df)

// Run Naive Bayes
val naive = new org.apache.spark.ml.classification.NaiveBayes().setLabelCol("categoryIndex").setFeaturesCol("features_scaled").setModelType("multinomial").setPredictionCol("NaiveCategory").setProbabilityCol("NaiveProbability").setRawPredictionCol("NaiveRaw")
val naive_pipe = new org.apache.spark.ml.Pipeline().setStages(Array(feature_pipe_model,naive))
val naive_model = naive_pipe.fit(train_df)
//naive_model.write.save("/data/etl_combine/calibration_ATT/NBModel")
//train_df.write.parquet("/data/etl_combine/calibration_ATT/train_df")
//test_df.write.parquet("/data/etl_combine/calibration_ATT/test_df")
//validate_df.write.parquet("/data/etl_combine/calibration_ATT/validate_df")

val predicted_df = naive_model.transform(validate_df)
val indexList = train_df.select("label","categoryIndex").distinct.toDF("predLabel","NaiveCategory")  //LogicCategory
val result_nb = predicted_df.join(indexList,"NaiveCategory")  //LogicCategory
result_nb.select("label","predLabel").rdd.filter(x => x.getString(0).equals(x.getString(1))).count
result_nb.count

val predicted_df2 = naive_model.transform(test_df)
//val indexList = train_df.select("label","categoryIndex").distinct.toDF("predLabel","NaiveCategory")  //LogicCategory
val result_nb2 = predicted_df2.join(indexList,"NaiveCategory")  //LogicCategory
result_nb2.select("label","predLabel").rdd.filter(x => x.getString(0).equals(x.getString(1))).count
result_nb2.count

import org.apache.spark.sql._   // Imports Row, Column, Dataframe, RDD etc.
import org.apache.spark.sql.types._  //Imports StructType, StructField etc.

var temp = train_df.select("final_concept","label").rdd.map(x=>Row(x.get(0).toString(),x.get(1)))
var schema = new StructType(Array(StructField("final_concept",StringType,nullable = true),
    StructField("label",StringType,nullable = true)))
train_df = spark.createDataFrame(temp,schema)
train_df.coalesce(1).write.format("org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option(
    "header","true").save("/data/etl_combine/calibration_ATT/train_df_feat_label")

var temp = test_df.select("final_concept","label").rdd.map(x=>Row(x.get(0).toString(),x.get(1)))
var schema = new StructType(Array(StructField("final_concept",StringType,nullable = true),
    StructField("label",StringType,nullable = true)))
test_df = spark.createDataFrame(temp,schema)
test_df.coalesce(1).write.format("org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option(
    "header","true").save("/data/etl_combine/calibration_ATT/test_df_feat_label")

var temp = validate_df.select("final_concept","label").rdd.map(x=>Row(x.get(0).toString(),x.get(1)))
var schema = new StructType(Array(StructField("final_concept",StringType,nullable = true),
    StructField("label",StringType,nullable = true)))
validate_df = spark.createDataFrame(temp,schema)
validate_df.coalesce(1).write.format("org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option(
    "header","true").save("/data/etl_combine/calibration_ATT/validate_df_feat_label")




//var gold_cat = gold.select("Label").distinct().select("Label").rdd.map(r=>r(0)).collect()
//var train_cat = train_df.select("Label").distinct().select("Label").rdd.map(r=>r(0)).collect()
//gold_cat.toSet--(train_cat.toSet.intersect(gold_cat.toSet))
//res37: scala.collection.immutable.Set[Any] = Set(Health and Fitness_Infertility, Technology and Computing_Unix)