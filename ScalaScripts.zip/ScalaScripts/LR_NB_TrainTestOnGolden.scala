
var gold = spark.read.parquet("/data/etl_combine/gold/").repartition(100)
//var gold = spark.read.format("org.apache.spark.sql.execution.datasources.parquet.ParquetFileFormat").load("/data/etl_combine/gold/").repartition(100)
gold = gold.filter("label not in ('Health and Fitness_Infertility', 'Technology and Computing_Unix')")
gold = gold.filter("final_concept_count > 0")

//Build a sample dataframe from golden df to try stratified sampling

// Sample from the top 2 categories
//gold.groupBy("label").count().sort($"count".desc).show(false)
//var temp = gold.filter("label in ('Arts and Entertainment_Music')").select("document","label","title").limit(10)
//var temp1 = gold.filter("label in ('News_UNKNOWN')").select("document","label","title").limit(5)
//temp = temp.union(temp1)
//val fractions = temp.select("label").distinct.rdd.keyBy(_.getString(0)).map(_._1).map(x=>(x,0.8)).collectAsMap.toMap
//var train = temp.stat.sampleBy("label",fractions,36L)
//var test = temp.except(train)

//**************Uncomment the below block in case you wish split golden data randomly into train and test
//////////
val fractions = gold.select("label").distinct.rdd.keyBy(_.getString(0)).map(_._1).map(x=>(x,0.8)).collectAsMap.toMap
var train_df = gold.stat.sampleBy("label",fractions,36L)
var test_df = gold.except(train_df)
//////////

//**************Comment below block if not reading those fixed 3K URLS
//////////
// For reading pred_3K and excluding them from gold
//var pred_3k = spark.read.format(
//    "org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").load(
//        "/data/etl_combine/save_predicted_df_3k/part-00000-2c010a9e-7956-4b27-bc40-3507cadac4f0.csv")
//pred_3k.createOrReplaceTempView("predview")
//
//// Train on 12K and test on the 3K URLs present n the pred_3k dataframe
//var test_df = gold.where("document IN (SELECT document FROM predview)")
//var train_df = gold.where("document NOT IN (SELECT document FROM predview)")
///////////



import org.apache.spark.ml.feature.StringIndexer
val indexer = new StringIndexer().setInputCol("correctLabel").setOutputCol("categoryIndex")
train_df = indexer.setHandleInvalid("skip").fit(train_df).transform(train_df)

val hashingTF = new org.apache.spark.ml.feature.HashingTF().setInputCol("final_concept").setOutputCol("features")
val idf = new org.apache.spark.ml.feature.IDF().setInputCol(hashingTF.getOutputCol).setOutputCol("features_scaled")
val feature_pipe = new org.apache.spark.ml.Pipeline().setStages(Array(hashingTF,idf))
val feature_pipe_model = feature_pipe.fit(train_df)

//test_df = feature_pipe_model.transform(test_df)
train_df = feature_pipe_model.transform(train_df)

//// Run Naive Bayes
//val naive = new org.apache.spark.ml.classification.NaiveBayes().setLabelCol("categoryIndex").setFeaturesCol("features_scaled").setModelType("multinomial").setPredictionCol("NaiveCategory").setProbabilityCol("NaiveProbability").setRawPredictionCol("NaiveRaw")
//val naive_pipe = new org.apache.spark.ml.Pipeline().setStages(Array(feature_pipe_model,naive))
//val naive_model = naive_pipe.fit(train_df)
//val predicted_df = naive_model.transform(test_df)
//val indexList = train_df.select("label","categoryIndex").distinct.toDF("predLabel","NaiveCategory")  //LogicCategory
//val result_nb = predicted_df.join(indexList,"NaiveCategory")  //LogicCategory
//result_nb.select("label","predLabel").rdd.filter(x => x.getString(0).equals(x.getString(1))).count
//result_nb.count
//
//// Run logistic
//val logistic = new org.apache.spark.ml.classification.LogisticRegression().setMaxIter(15).setLabelCol("categoryIndex").setFeaturesCol("features_scaled").setPredictionCol("LogicCategory").setFamily("multinomial").setRawPredictionCol("LogicRaw").setProbabilityCol("LogicProbability")
//val logistic_pipe = new org.apache.spark.ml.Pipeline().setStages(Array(feature_pipe_model,naive))
//val logistic_model = logistic_pipe.fit(train_df)
//val predicted_df = logistic_model.transform(test_df)
//val indexList = train_df.select("label","categoryIndex").distinct.toDF("predLabel","LogicCategory")  //LogicCategory
//val result_lr = predicted_df.join(indexList,"LogicCategory")  //LogicCategory
//result_lr.select("label","predLabel").rdd.filter(x => x.getString(0).equals(x.getString(1))).count
//result_lr.count

result.select("document","correctLabel","predLabel","label").toDF(
    "document","HumanLabel","NBLabel","IBlabel"
    ).coalesce(1).write.format("org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").save("/data/gold_train_test_csv/nb_labels")



//var gold_cat = gold.select("Label").distinct().select("Label").rdd.map(r=>r(0)).collect()
//var train_cat = train_df.select("Label").distinct().select("Label").rdd.map(r=>r(0)).collect()
//gold_cat.toSet--(train_cat.toSet.intersect(gold_cat.toSet))
//res37: scala.collection.immutable.Set[Any] = Set(Health and Fitness_Infertility, Technology and Computing_Unix)
