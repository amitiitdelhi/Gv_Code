var train_df = spark.read.parquet("/data/etl_combine/kuljain_14_1/res_train_11200_URLs")
var validate_df = spark.read.parquet("/data/etl_combine/kuljain_14_1/res_validate_2800_URLs")
var test_df = spark.read.parquet("/data/etl_combine/kuljain_14_1/res_test_1K_URLs")


validate_df = validate_df.union(train_df)
validate_df = validate_df.union(test_df)
val fractions = validate_df.select("correctLabel").distinct.rdd.keyBy(_.getString(0)).map(_._1).map(x=>(x,0.8)).collectAsMap.toMap
train_df = validate_df.stat.sampleBy("correctLabel",fractions,36L) 
validate_df = validate_df.except(train_df)


import org.apache.spark.ml.feature.StringIndexer
val indexer = new StringIndexer().setInputCol("correctLabel").setOutputCol("categoryIndex")
train_df = indexer.setHandleInvalid("skip").fit(train_df).transform(train_df)

val hashingTF = new org.apache.spark.ml.feature.HashingTF().setInputCol("final_concept").setOutputCol("features")
val idf = new org.apache.spark.ml.feature.IDF().setInputCol(hashingTF.getOutputCol).setOutputCol("features_scaled")
val feature_pipe = new org.apache.spark.ml.Pipeline().setStages(Array(hashingTF,idf))
val feature_pipe_model = feature_pipe.fit(train_df)

// Run logistic
val logistic = new org.apache.spark.ml.classification.LogisticRegression().setMaxIter(15).setLabelCol("categoryIndex").setFeaturesCol("features_scaled").setPredictionCol("LogicCategory").setFamily("multinomial").setRawPredictionCol("LogicRaw").setProbabilityCol("LogicProbability")
val logistic_pipe = new org.apache.spark.ml.Pipeline().setStages(Array(feature_pipe_model,logistic))
val logistic_model = logistic_pipe.fit(train_df)

//logistic_model.write.save("/data/etl_combine/kuljain_14_1/LogisticModel")
//train_df.select("correctLabel","categoryIndex").coalesce(1).write.format(
//    "org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").save("/data/etl_combine/kuljain_14_1/traindf_indexList/")

//import org.apache.spark.ml._
//val logistic_model = PipelineModel.read.load("/data/etl_combine/kuljain_14_1/LogisticModel")
//var train_df = spark.read.format(
//    "org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").load(
//        "/data/etl_combine/kuljain_14_1/traindf_indexList/part-00000-0769a213-23fd-4cb1-9d59-310c3ae8d7a3.csv")


val predicted_df = logistic_model.transform(validate_df)
val indexList = train_df.select("correctLabel","categoryIndex").distinct.toDF("predLabel","LogicCategory")  //LogicCategory
val result_lr = predicted_df.join(indexList,"LogicCategory")  //LogicCategory
result_lr.select("correctLabel","predLabel").rdd.filter(x => x.getString(0).equals(x.getString(1))).count
result_lr.count

val predicted_df_2 = logistic_model.transform(test_df)
val indexList_2 = train_df.select("correctLabel","categoryIndex").distinct.toDF("predLabel","LogicCategory")  //LogicCategory
val result_lr_2 = predicted_df_2.join(indexList_2,"LogicCategory")  //LogicCategory
result_lr_2.select("correctLabel","predLabel").rdd.filter(x => x.getString(0).equals(x.getString(1))).count
result_lr_2.count








// Write all 3 dataframes (train, test and pred_3k) to disk and comapre their most frequent concepts

import org.apache.spark.sql._   // Imports Row, Column, Dataframe, RDD etc.
import org.apache.spark.sql.types._  //Imports StructType, StructField etc.

// For pred_3k_gold
// Do changes to the needed dataframe after conversion to rdd
var temp = pred_3k_gold.select("document","final_concept","final_concept_count","correctLabel").rdd.map(x=>Row(x.get(0),x.get(1).toString(),x.get(2),x.get(3)))
// Construct the schema for the new df which will be made by reconverting above rdd to df
val newSchema = new StructType(
    Array(StructField("document",StringType,nullable = true),
    StructField("final_concept",StringType,nullable = true),
    StructField("final_concept_count",IntegerType,nullable = true),
    StructField("correctLabel",StringType,nullable = true))
    )
var temp2 = spark.createDataFrame(temp,newSchema)
temp2.coalesce(1).write.format("org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").save("/data/etl_combine/kuldeepjain_pred3k/")

// For train_df
// Do changes to the needed dataframe after conversion to rdd
var temp = train_df.select("document","final_concept","final_concept_count","correctLabel").rdd.map(x=>Row(x.get(0),x.get(1).toString(),x.get(2),x.get(3)))
// Construct the schema for the new df which will be made by reconverting above rdd to df
val newSchema = new StructType(
    Array(StructField("document",StringType,nullable = true),
    StructField("final_concept",StringType,nullable = true),
    StructField("final_concept_count",IntegerType,nullable = true),
    StructField("correctLabel",StringType,nullable = true))
    )
var temp2 = spark.createDataFrame(temp,newSchema)
temp2.coalesce(1).write.format("org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").save("/data/etl_combine/kuldeepjain_train_df/")

// For test_df
// Do changes to the needed dataframe after conversion to rdd
var temp = test_df.select("document","final_concept","final_concept_count","correctLabel").rdd.map(x=>Row(x.get(0),x.get(1).toString(),x.get(2),x.get(3)))
// Construct the schema for the new df which will be made by reconverting above rdd to df 
val newSchema = new StructType(
    Array(StructField("document",StringType,nullable = true),
    StructField("final_concept",StringType,nullable = true),
    StructField("final_concept_count",IntegerType,nullable = true),
    StructField("correctLabel",StringType,nullable = true))
    )
var temp2 = spark.createDataFrame(temp,newSchema)
temp2.coalesce(1).write.format("org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").save("/data/etl_combine/kuldeepjain_test_df/")
