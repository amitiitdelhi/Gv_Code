
import org.apache.spark.sql._   // Imports Row, Column, Dataframe, RDD etc.
import org.apache.spark.sql.types._  //Imports StructType, StructField etc.

var res = spark.read.parquet("/data/etl_combine/gold")
res = res.select("document","correctLabel","title","content","final_concept","final_concept_count")
var prod = spark.read.parquet("/data/etl_combine/cf_out")

prod.createOrReplaceTempView("productionView")
var missed_URLs = res.where("document NOT IN (SELECT document FROM productionView)")

// Save gold_15k dataframe (with concepts) as csv to disk 
var temp = res.select("document","correctLabel","title","final_concept","final_concept_count").rdd.map(
    x=>Row(x.get(0),x.get(1),x.get(2),x.get(3).toString(),x.get(4)))
// Construct the schema for the new df which will be made by reconverting above rdd to df 
val newSchema = new StructType(
    Array(StructField("document",StringType,nullable = true),
    StructField("correctLabel",StringType,nullable = true),
    StructField("title",StringType,nullable = true),
    StructField("final_concept",StringType,nullable = true),
    StructField("final_concept_count",IntegerType,nullable = true))
    )
var temp2 = spark.createDataFrame(temp,newSchema)
temp2.coalesce(1).write.format("org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").save("/data/etl_combine/gold_15k_csv_with_concepts/")

val result = res.join(prod.select("document","final_concept").toDF("document","final_concept_prod"),"document","outer")

// Merge both prod and res results with the extracted concepts and save to disk
var temp = result.select("document","final_concept","final_concept_prod","final_concept_count","correctLabel").rdd.map(
    x=>Row(x.get(0),x.get(1).toString(),x.get(2).toString(),x.get(3),x.get(4)))
// Construct the schema for the new df which will be made by reconverting above rdd to df 
val newSchema = new StructType(
    Array(StructField("document",StringType,nullable = true),
    StructField("final_concept",StringType,nullable = true),
    StructField("final_concept_prod",StringType,nullable = true),
    StructField("final_concept_count",IntegerType,nullable = true),
    StructField("correctLabel",StringType,nullable = true))
    )
var temp2 = spark.createDataFrame(temp,newSchema)
temp2.coalesce(1).write.format("org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").save("/data/etl_combine/compare_cf_out_prod_res/")
