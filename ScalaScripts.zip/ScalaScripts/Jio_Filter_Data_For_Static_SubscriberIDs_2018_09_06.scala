//##  Code to be run on all media, control and user plane files to filter data for the already saved static list of subscriber ids ##//

import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.fs.Path
import org.apache.hadoop.fs.FileStatus

// Read staticList to be used for filtering
var static_subscriber_list_location = "hdfs://jiobigdataplatform/user/SIJLnetwork_guavus_user/priyanshu/static_subscriber_list/"   // location of static file having the list of subsriber ids
var folder_to_be_filtered = "hdfs://jiobigdataplatform/data/network/probes/controlPlane_V1/flatfiles_enc/2018-09-01"   // folder containing the files to be filtered


var hashing_offset = 10
var subscriber_id_colname_hashed = "subscriber_id_hashed"

//user-defined function to be used for hashing
def hash_subscriberId : (Long=>Long) = (subscriber_id : Long) => {subscriber_id+hashing_offset.toLong}

//user-defined function to filter a file and write it
def filter_and_write_file(filename: String) = {
  //print (filename)
  //var output_file_location = filename.replace("flatfiles_enc","flatfiles_enc_filtered")+"_filtered/"   // location where the filtered files will be stored
  var output_file_location = filename.replace("data/network","user/SIJLnetwork_guavus_user/priyanshu")+"_filtered_10K/"   // location where the filtered files will be stored
  // Read the data file to be filtered and filter it using the above created SQL View
  var data = spark.read.json(filename)
  data = data.where("subscriber_id IN (SELECT subscriber_id FROM staticListView)")
  // Hash the subscriber IDs by adding hashing_offset to the original IDs and then save the filtered files
  val hash_subscriberId_udf = udf(hash_subscriberId)
  data = data.withColumn(subscriber_id_colname_hashed,hash_subscriberId_udf(col("subscriber_id"))).drop("subscriber_id")
  data.coalesce(1).write.format("org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").mode("overwrite").option("header","true").save(output_file_location)  
}


// Read the customer IDs from the saved static file 
var staticList = spark.read.format("org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").option("inferSchema","true").load(static_subscriber_list_location)
// Create an SQL view for these customer IDs - this View will be used for filtering data later
staticList.createOrReplaceTempView("staticListView")


val fs = FileSystem.get(new Configuration())
// Read all files from the given folder and filter them one by one
var all_elements = fs.listStatus(new Path(folder_to_be_filtered))
for (i <- 0 to all_elements.length-1){
//  print (i);
  if(all_elements(i).isDirectory!=true){
    var file_to_be_filtered = all_elements(i).getPath.toString
    filter_and_write_file(file_to_be_filtered)
  }
}


hdfs://jiobigdataplatform/user/SIJLnetwork_guavus_user/
