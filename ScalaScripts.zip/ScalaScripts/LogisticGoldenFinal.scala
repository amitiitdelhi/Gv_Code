var train_df = spark.read.parquet("/data/etl_combine/trainData").repartition(66)
var test_df = spark.read.parquet("/data/etl_combine/testData").repartition(66)

import org.apache.spark.ml.feature.StringIndexer

test_df = test_df.filter("final_concept_count > 0")
train_df = train_df.filter("final_concept_count > 0")

var gold = spark.read.parquet("/data/etl_combine/gold/").repartition(48)
gold = gold.filter("final_concept_count > 0")

// Combine train and test
train_df = train_df.union(test_df)
gold.createOrReplaceTempView("goldview")
train_df = train_df.where("document NOT IN (SELECT document FROM goldview)")

// Assign null value to test_df
import org.apache.spark.sql.types.{
    StructType, StructField, StringType, IntegerType}
import org.apache.spark.sql.Row
val schema = StructType(
    StructField("k", StringType, true) ::
    StructField("v", IntegerType, false) :: Nil)
// Spark < 2.0
// sqlContext.createDataFrame(sc.emptyRDD[Row], schema) 
test_df = spark.createDataFrame(sc.emptyRDD[Row], schema)

train_df = train_df.repartition(66)
val indexer = new StringIndexer().setInputCol("label").setOutputCol("categoryIndex")
train_df = indexer.setHandleInvalid("skip").fit(train_df).transform(train_df)



val hashingTF = new org.apache.spark.ml.feature.HashingTF().setInputCol("final_concept").setOutputCol("features")
val idf = new org.apache.spark.ml.feature.IDF().setInputCol(hashingTF.getOutputCol).setOutputCol("features_scaled")
val feature_pipe = new org.apache.spark.ml.Pipeline().setStages(Array(hashingTF,idf))
val feature_pipe_model = feature_pipe.fit(train_df)
//val logistic = new org.apache.spark.ml.classification.LogisticRegression().setMaxIter(15).setLabelCol("categoryIndex").setFeaturesCol("features_scaled").setPredictionCol("LogicCategory").setFamily("multinomial").setRawPredictionCol("LogicRaw").setProbabilityCol("LogicProbability")
val naive = new org.apache.spark.ml.classification.NaiveBayes().setLabelCol("categoryIndex").setFeaturesCol("features_scaled").setModelType("multinomial").setPredictionCol("NaiveCategory").setProbabilityCol("NaiveProbability").setRawPredictionCol("NaiveRaw")


val logistic_pipe = new org.apache.spark.ml.Pipeline().setStages(Array(feature_pipe_model,naive))
val logistic_model = logistic_pipe.fit(train_df)
//logistic_model.write.save("/data/etl_combine/att_logistic_model")

/*
import org.apache.spark.ml._
val logistic_model = PipelineModel.read.load("/data/etl_combine/att_logistic_model")
*/
gold = gold.filter("label not in ('Health and Fitness_Infertility', 'Technology and Computing_Unix')")
val predicted_df = logistic_model.transform(gold)

val indexList = train_df.select("label","categoryIndex").distinct.toDF("predLabel","NaiveCategory")  //LogicCategory
val result = predicted_df.join(indexList,"NaiveCategory")

result.select("label","predLabel").rdd.filter(x => x.getString(0).equals(x.getString(1))).count
result.count

result.select("document","correctLabel","predLabel","label").toDF("document","HumanLabel","IBLabel","LRlabel").coalesce(1).write.format("org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").save("/data/att_gold_csv/all_3_labels_gold")



//var gold_cat = gold.select("Label").distinct().select("Label").rdd.map(r=>r(0)).collect()
//var train_cat = train_df.select("Label").distinct().select("Label").rdd.map(r=>r(0)).collect()
//gold_cat.toSet--(train_cat.toSet.intersect(gold_cat.toSet))
//res37: scala.collection.immutable.Set[Any] = Set(Health and Fitness_Infertility, Technology and Computing_Unix)
