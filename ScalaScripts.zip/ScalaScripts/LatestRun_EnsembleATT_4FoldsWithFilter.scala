
//var temp11 = spark.read.format("org.apache.spark.sql.execution.datasources.parquet.ParquetFileFormat").load("/data/etl_combine/latest_run/att_extracted_filtered")
//var conf_score = spark.read.format("org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option(
//    "header","true").option("sep","\t").load("/data/etl_combine/latest_run/Prasad_ConfScore_100k.txt")
//conf_score = conf_score.select("URL","Confidence_Level").toDF("document","conf_level")
//temp11 = temp11.filter("conf_level NOT IN ('low','NA')")
//temp11.write.format("org.apache.spark.sql.execution.datasources.parquet.ParquetFileFormat").save("/data/etl_combine/latest_run/att_extracted_filtered_conf_score")

// Uncomment below code snippet if you want to save concepts of 100K as csv file 
//
//import org.apache.spark.sql._   // Imports Row, Column, Dataframe, RDD etc.
//import org.apache.spark.sql.types._  //Imports StructType, StructField etc.
//temp11 = temp11.select("document","label","final_concept")
//var temp = temp11.rdd.map(x=>Row(x.get(0),x.get(1),x.get(2).toString()))
//val newSchema = new StructType(
//    Array(StructField("document",StringType,nullable = true),
//    StructField("label",StringType,nullable = true),
//    StructField("final_concept",StringType,nullable = true))
//    )
//var temp_new = spark.createDataFrame(temp,newSchema)
//temp_new.coalesce(1).write.format("org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").save("/data/etl_combine/latest_run/att_all_confscore_concepts_csv/")

//var fractions = temp11.select("label").distinct.rdd.keyBy(_.getString(0)).map(_._1).map(x=>(x,0.50)).collectAsMap.toMap
//var df1 = temp11.stat.sampleBy("label",fractions,36L)
//var df2 = temp11.except(df1)
//
//var fractions = df1.select("label").distinct.rdd.keyBy(_.getString(0)).map(_._1).map(x=>(x,0.50)).collectAsMap.toMap
//var df11 = df1.stat.sampleBy("label",fractions,36L)
//var df12 = df1.except(df11)
//
//var fractions = df2.select("label").distinct.rdd.keyBy(_.getString(0)).map(_._1).map(x=>(x,0.50)).collectAsMap.toMap
//var df21 = df2.stat.sampleBy("label",fractions,36L)
//var df22 = df2.except(df21)
//
//df11.write.format("org.apache.spark.sql.execution.datasources.parquet.ParquetFileFormat").save("/data/etl_combine/latest_run/df11_conf_score")
//df12.write.format("org.apache.spark.sql.execution.datasources.parquet.ParquetFileFormat").save("/data/etl_combine/latest_run/df12_conf_score")
//df21.write.format("org.apache.spark.sql.execution.datasources.parquet.ParquetFileFormat").save("/data/etl_combine/latest_run/df21_conf_score")
//df22.write.format("org.apache.spark.sql.execution.datasources.parquet.ParquetFileFormat").save("/data/etl_combine/latest_run/df22_conf_score")

///////////////////////////////////////////////////////////////////////////
// SAMPLING ENDS
//////////////////////////////////////////////////////////////////////////

var temp11 = spark.read.format("org.apache.spark.sql.execution.datasources.parquet.ParquetFileFormat").load("/data/etl_combine/latest_run/att_extracted_filtered_conf_score")
//// For reading one of the folds
//var test_df = spark.read.format("org.apache.spark.sql.execution.datasources.parquet.ParquetFileFormat").load("/data/etl_combine/latest_run/df22_conf_score")
// For human labels
var test_df = spark.read.format("org.apache.spark.sql.execution.datasources.parquet.ParquetFileFormat").load("/data/etl_combine/production_output/Run1/label_si_out")
//var human_conf_score = spark.read.format("org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option(
//    "header","true").option("sep","\t").load("/data/etl_combine/latest_run/Prasad_ConfScore_15k.txt")
//human_conf_score = human_conf_score.select("URL","Confidence_Level").toDF("document","conf_level")
//test_df = test_df.join(human_conf_score,"document")
//test_df = test_df.filter("conf_level NOT IN ('low','NA')")
test_df = test_df.drop("label_id")

//// For uncat reports
//var test_df = spark.read.format("org.apache.spark.sql.execution.datasources.parquet.ParquetFileFormat").load("/data/etl_combine/latest_run/Uncat_500/cf_out/")

var train_df = temp11.except(test_df)

var n = 50
var top_n = temp11.groupBy("label").count.sort($"count".desc).limit(n)
top_n.createOrReplaceTempView("top_n_view")
train_df = train_df.where("label IN (SELECT label from top_n_view)")
test_df = test_df.where("label IN (SELECT label from top_n_view)")

////
train_df.createOrReplaceTempView("trainView")
test_df.createOrReplaceTempView("testView")
train_df.where("document IN (SELECT document from testView)").count
test_df.where("document IN (SELECT document from trainView)").count

train_df.select("label").distinct.count
test_df.select("label").distinct.count
1.0*train_df.count/test_df.count
////

train_df = train_df.where("document NOT IN (SELECT document from testView)").repartition(50)

import org.apache.spark.ml.feature.StringIndexer
val indexer = new StringIndexer().setInputCol("label").setOutputCol("categoryIndex")   //setHandleInvalid("keep")
train_df = indexer.fit(train_df).transform(train_df)

val hashingTF = new org.apache.spark.ml.feature.HashingTF().setInputCol("final_concept").setOutputCol("features")
val idf = new org.apache.spark.ml.feature.IDF().setInputCol(hashingTF.getOutputCol).setOutputCol("features_scaled")
val feature_pipe = new org.apache.spark.ml.Pipeline().setStages(Array(hashingTF,idf))
val feature_pipe_model = feature_pipe.fit(train_df)

test_df = feature_pipe_model.transform(test_df)
train_df = feature_pipe_model.transform(train_df)

val naive = new org.apache.spark.ml.classification.NaiveBayes().setLabelCol("categoryIndex").setFeaturesCol(
    "features_scaled").setModelType("multinomial").setPredictionCol("NaiveCategory").setProbabilityCol("NaiveProbability").setRawPredictionCol("NaiveRaw")
val logistic1 = new org.apache.spark.ml.classification.LogisticRegression().setMaxIter(15).setLabelCol(
    "categoryIndex").setFeaturesCol("features_scaled").setPredictionCol("Logic1Category").setFamily("multinomial").setRawPredictionCol("Logic1Raw").setProbabilityCol("Logic1Probability")
val ensembler = new Ensembler()
val train = ensembler.ensembling(Array(logistic1,naive),train_df,"categoryIndex","label",4,"combine_vec")
val train_result = train._1
val max = train._2

// train_result.write.parquet("/data/etl_combine/gold_ens_4fold_save/train_result")
// train_df.write.parquet("/data/etl_combine/gold_ens_4fold_save/train_df")
// test_df.write.parquet("/data/etl_combine/gold_ens_4fold_save/test_df")
// max: Int = 289
//var train_result = spark.read.parquet("/data/etl_combine/gold_ens_4fold_save/train_result").repartition(48)
//var train_df = spark.read.parquet("/data/etl_combine/gold_ens_4fold_save/train_df").repartition(48)
//var test_df = spark.read.parquet("/data/etl_combine/gold_ens_4fold_save/test_df").repartition(48)
//var max = 289

val model_result = ensembler.fit(Array(logistic1,naive),train_df)
val test_result = ensembler.predict(Array(logistic1,naive),model_result,test_df,"combine_vec",max)

val logistic = new org.apache.spark.ml.classification.LogisticRegression().setMaxIter(15).setLabelCol("categoryIndex").setFeaturesCol("combine_vec").setPredictionCol("LogicCategory").setFamily("multinomial")
val logistic_model = logistic.fit(train_result)
val predicted_df = logistic_model.transform(test_result)

val indexList = train_df.select("label","categoryIndex").distinct.toDF("predLabel","LogicCategory")
// This result variable contains the original label and predicted label for all the URLs from the test dataset 
val result = predicted_df.join(indexList,"LogicCategory")
result.select("label","predLabel").rdd.filter(x => x.getString(0).equals(x.getString(1))).count
result.count

//predicted_df.select("document","label","LogicCategory").coalesce(1).write.format(
//     "org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").save("/data/etl_combine/latest_run/pred_df_df22_confscore")
//indexList.coalesce(1).write.format(
//     "org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").save("/data/etl_combine/latest_run/indexList_df22_confscore")
//     
//     
//result.select("document","correctLabel","predLabel").coalesce(1).write.format(
//    "org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").save("/data/etl_combine/production_output/Run5_top50_8020/result_8020_prod/")
//train_df.select("document","correctLabel").coalesce(1).write.format(
//    "org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").save("/data/etl_combine/production_output/Run5_top50_8020/train_8020_prod/")
//test_df.select("document","correctLabel").coalesce(1).write.format(
//    "org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").save("/data/etl_combine/production_output/Run5_top50_8020/test_8020_prod/")
//
    