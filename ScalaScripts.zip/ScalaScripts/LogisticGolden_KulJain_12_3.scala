
var gold = spark.read.parquet("/data/etl_combine/gold/").repartition(100)
gold = gold.filter("label not in ('Health and Fitness_Infertility', 'Technology and Computing_Unix')")
gold = gold.filter("final_concept_count > 0")

//var pred_3k_gold = gold.where("document IN (SELECT document FROM predview)")
//gold = gold.where("document NOT IN (SELECT document FROM predview)")

//val fractions = gold.select("correctLabel").distinct.rdd.keyBy(_.getString(0)).map(_._1).map(x=>(x,0.8)).collectAsMap.toMap
//var train_df = gold.stat.sampleBy("correctLabel",fractions,36L)
//var test_df = gold.except(train_df)

// Comment below block if not reading those foxed 3K URLS
//////////
// For reading pred_3K and excluding them from gold
var pred_3k = spark.read.format(
    "org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").load(
        "/data/etl_combine/save_predicted_df_3k/part-00000-2c010a9e-7956-4b27-bc40-3507cadac4f0.csv")
pred_3k.createOrReplaceTempView("predview")

// Train on 12K and test on the 3K URLs present n the pred_3k dataframe
var test_df = gold.where("document IN (SELECT document FROM predview)")
var train_df = gold.where("document NOT IN (SELECT document FROM predview)")
///////////

import org.apache.spark.ml.feature.StringIndexer
val indexer = new StringIndexer().setInputCol("correctLabel").setOutputCol("categoryIndex")
train_df = indexer.setHandleInvalid("skip").fit(train_df).transform(train_df)

val hashingTF = new org.apache.spark.ml.feature.HashingTF().setInputCol("final_concept").setOutputCol("features")
val idf = new org.apache.spark.ml.feature.IDF().setInputCol(hashingTF.getOutputCol).setOutputCol("features_scaled")
val feature_pipe = new org.apache.spark.ml.Pipeline().setStages(Array(hashingTF,idf))
val feature_pipe_model = feature_pipe.fit(train_df)

// Run logistic
val logistic = new org.apache.spark.ml.classification.LogisticRegression().setMaxIter(15).setLabelCol("categoryIndex").setFeaturesCol("features_scaled").setPredictionCol("LogicCategory").setFamily("multinomial").setRawPredictionCol("LogicRaw").setProbabilityCol("LogicProbability")
val logistic_pipe = new org.apache.spark.ml.Pipeline().setStages(Array(feature_pipe_model,logistic))
val logistic_model = logistic_pipe.fit(train_df)
//logistic_model.write.save("LogisticModelTrainedOnGolden")
//import org.apache.spark.ml._
//val logistic_model = PipelineModel.read.load("/data/etl_combine/save_logisticmodel")
val predicted_df = logistic_model.transform(test_df)
val indexList = train_df.select("correctLabel","categoryIndex").distinct.toDF("predLabel","LogicCategory")  //LogicCategory
val result_lr = predicted_df.join(indexList,"LogicCategory")  //LogicCategory
result_lr.select("correctLabel","predLabel").rdd.filter(x => x.getString(0).equals(x.getString(1))).count
result_lr.count

// Run Naive Bayes
val naive = new org.apache.spark.ml.classification.NaiveBayes().setLabelCol("categoryIndex").setFeaturesCol("features_scaled").setModelType("multinomial").setPredictionCol("NaiveCategory").setProbabilityCol("NaiveProbability").setRawPredictionCol("NaiveRaw")
val naive_pipe = new org.apache.spark.ml.Pipeline().setStages(Array(feature_pipe_model,naive))
val naive_model = naive_pipe.fit(train_df)
val predicted_df = naive_model.transform(test_df)
val indexList = train_df.select("correctLabel","categoryIndex").distinct.toDF("predLabel","NaiveCategory")  //LogicCategory
val result_nb = predicted_df.join(indexList,"NaiveCategory")  //LogicCategory
result_nb.select("correctLabel","predLabel").rdd.filter(x => x.getString(0).equals(x.getString(1))).count
result_nb.count




//result_lr.select("document","correctLabel","predLabel","label").toDF("document","HumanLabel","NBLabel","IBlabel").coalesce(1).write.format(
//"org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").save("/data/gold_train_test_csv/nb_labels")

val predicted_df_2 = logistic_model.transform(pred_3k_gold)
val indexList_2 = train_df.select("correctLabel","categoryIndex").distinct.toDF("predLabel","LogicCategory")  //LogicCategory
val result_lr_2 = predicted_df_2.join(indexList_2,"LogicCategory")  //LogicCategory
result_lr_2.select("correctLabel","predLabel").rdd.filter(x => x.getString(0).equals(x.getString(1))).count
result_lr_2.count

// Write all 3 dataframes (train, test and pred_3k) to disk and comapre their most frequent concepts

import org.apache.spark.sql._   // Imports Row, Column, Dataframe, RDD etc.
import org.apache.spark.sql.types._  //Imports StructType, StructField etc.

// For pred_3k_gold
// Do changes to the needed dataframe after conversion to rdd
var temp = pred_3k_gold.select("document","final_concept","final_concept_count","correctLabel").rdd.map(x=>Row(x.get(0),x.get(1).toString(),x.get(2),x.get(3)))
// Construct the schema for the new df which will be made by reconverting above rdd to df
val newSchema = new StructType(
    Array(StructField("document",StringType,nullable = true),
    StructField("final_concept",StringType,nullable = true),
    StructField("final_concept_count",IntegerType,nullable = true),
    StructField("correctLabel",StringType,nullable = true))
    )
var temp2 = spark.createDataFrame(temp,newSchema)
temp2.coalesce(1).write.format("org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").save("/data/etl_combine/kuldeepjain_pred3k/")

// For train_df
// Do changes to the needed dataframe after conversion to rdd
var temp = train_df.select("document","final_concept","final_concept_count","correctLabel").rdd.map(x=>Row(x.get(0),x.get(1).toString(),x.get(2),x.get(3)))
// Construct the schema for the new df which will be made by reconverting above rdd to df
val newSchema = new StructType(
    Array(StructField("document",StringType,nullable = true),
    StructField("final_concept",StringType,nullable = true),
    StructField("final_concept_count",IntegerType,nullable = true),
    StructField("correctLabel",StringType,nullable = true))
    )
var temp2 = spark.createDataFrame(temp,newSchema)
temp2.coalesce(1).write.format("org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").save("/data/etl_combine/kuldeepjain_train_df/")

// For test_df
// Do changes to the needed dataframe after conversion to rdd
var temp = test_df.select("document","final_concept","final_concept_count","correctLabel").rdd.map(x=>Row(x.get(0),x.get(1).toString(),x.get(2),x.get(3)))
// Construct the schema for the new df which will be made by reconverting above rdd to df 
val newSchema = new StructType(
    Array(StructField("document",StringType,nullable = true),
    StructField("final_concept",StringType,nullable = true),
    StructField("final_concept_count",IntegerType,nullable = true),
    StructField("correctLabel",StringType,nullable = true))
    )
var temp2 = spark.createDataFrame(temp,newSchema)
temp2.coalesce(1).write.format("org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").save("/data/etl_combine/kuldeepjain_test_df/")
