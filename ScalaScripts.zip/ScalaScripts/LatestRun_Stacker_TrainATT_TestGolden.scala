// Read all data
var temp11 = spark.read.format("org.apache.spark.sql.execution.datasources.parquet.ParquetFileFormat").load("/data/etl_combine/latest_run/att_extracted_filtered")

var temp11 = spark.read.option("header","true").csv("/data/etl_combine/latest_run/train_111k_with_concepts_csv/part-00000-7f1b8eba-c542-4932-91d0-89d363806d8d.csv")
var split_concepts = udf((final_concept: String)=>{final_concept.split(",").map(x=>x.trim)})
temp11 = temp11.withColumn("final_concept_modified",split_concepts(col("final_concept")))
temp11 = temp11.drop("final_concept").withColumnRenamed("final_concept_modified","final_concept")
var gold = spark.read.option("header","true").csv("/data/etl_combine/latest_run/gold_13k_with_concepts_csv/")
gold = gold.withColumn("final_concept_modified",split_concepts(col("final_concept")))
gold = gold.drop("final_concept").withColumnRenamed("final_concept_modified","final_concept")
gold.createOrReplaceTempView("goldView")

// Read golden dataset
var gold = spark.read.format("org.apache.spark.sql.execution.datasources.parquet.ParquetFileFormat").load("/data/etl_combine/production_output/Run1/label_si_out")
gold.createOrReplaceTempView("goldView")

// Read Uncat dataset
var uncat_urls = spark.read.format("org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option(
    "inferSchema","true").option("header","true").load("/data/etl_combine/latest_run/uncat_1200.csv")
uncat_urls = uncat_urls.select("document","label").dropDuplicates()
var uncat = spark.read.format("org.apache.spark.sql.execution.datasources.parquet.ParquetFileFormat").load("/data/etl_combine/latest_run/manual_data_cf_out")
uncat = uncat.select("document","final_concept").dropDuplicates()
uncat = uncat.join(uncat_urls,"document")
uncat = uncat.dropDuplicates("document","label")
uncat.createOrReplaceTempView("uncatView")

// Form train and test data
//var test_df = uncat
//var train_df = temp11.where("document NOT IN (SELECT document FROM uncatView)")
var test_df1 = gold
var test_df2 = uncat
var train_df = temp11.where("document NOT IN (SELECT document FROM goldView)")
train_df = train_df.where("document NOT IN (SELECT document FROM uncatView)")

// Filter for those particular 15 Categories
import org.apache.spark.sql.functions._

// Old Labels
val labels_to_retain = List("Adult Content_UNKNOWN", "Arts and Entertainment_Television", "Arts and Entertainment_Music", "Arts and Entertainment_Celebrity Fan/Gossip",
    "Careers_Job Search","Hobbies and Interests_Freelance Writing", "Hobbies and Interests_Video & Computer Games", "News_UNKNOWN", "Real Estate_Buying/Selling Homes", "Shopping_Engines",
    "Society_Dating", "Style and Fashion_Clothing", "Sports_Football", "Technology and Computing_Internet Technology", "Technology and Computing_Web Search")
// New Labels
val labels_to_retain = List("Adult Content_UNKNOWN", "Arts and Entertainment_Television", "Arts and Entertainment_Music", "Arts and Entertainment_Celebrity Fan/Gossip",
    "Careers_Job Search","Hobbies and Interests_Freelance Writing", "Hobbies and Interests_Video & Computer Games", "News_UNKNOWN", "Real Estate_Buying/Selling Homes", "Shopping_Engines",
    "Society_Dating", "Style and Fashion_Clothing", "Sports_Football", "Technology and Computing_Internet Technology", "Technology and Computing_Web Search")

    
var modifyLabel = udf((label:String) => if(labels_to_retain.contains(label)) label else "Others")

train_df = train_df.withColumn("label_modified",modifyLabel(col("label")))
train_df = train_df.drop("label").withColumnRenamed("label_modified","label")
train_df = train_df.filter("label not in ('Others')")

test_df1 = test_df1.withColumn("label_modified",modifyLabel(col("label")))
test_df1 = test_df1.drop("label").withColumnRenamed("label_modified","label")

test_df2 = test_df2.withColumn("label_modified",modifyLabel(col("label")))
test_df2 = test_df2.drop("label").withColumnRenamed("label_modified","label")


////
train_df.createOrReplaceTempView("trainView")
test_df1.createOrReplaceTempView("test1View")
test_df2.createOrReplaceTempView("test2View")
////

train_df = train_df.where("document NOT IN (SELECT document from test1View)")
train_df = train_df.where("document NOT IN (SELECT document from test2View)")

import org.apache.spark.ml.feature.StringIndexer
val indexer = new StringIndexer().setInputCol("label").setOutputCol("categoryIndex")   //setHandleInvalid("keep")
train_df = indexer.fit(train_df).transform(train_df)

val hashingTF = new org.apache.spark.ml.feature.HashingTF().setInputCol("final_concept").setOutputCol("features")
val idf = new org.apache.spark.ml.feature.IDF().setInputCol(hashingTF.getOutputCol).setOutputCol("features_scaled")
val feature_pipe = new org.apache.spark.ml.Pipeline().setStages(Array(hashingTF,idf))
val feature_pipe_model = feature_pipe.fit(train_df)

test_df1 = feature_pipe_model.transform(test_df1)
test_df2 = feature_pipe_model.transform(test_df2)
train_df = feature_pipe_model.transform(train_df)

val naive = new org.apache.spark.ml.classification.NaiveBayes().setLabelCol("categoryIndex").setFeaturesCol(
    "features_scaled").setModelType("multinomial").setPredictionCol("NaiveCategory").setProbabilityCol("NaiveProbability").setRawPredictionCol("NaiveRaw")
val logistic1 = new org.apache.spark.ml.classification.LogisticRegression().setMaxIter(15).setLabelCol(
    "categoryIndex").setFeaturesCol("features_scaled").setPredictionCol("Logic1Category").setFamily("multinomial").setRawPredictionCol("Logic1Raw").setProbabilityCol("Logic1Probability")
val ensembler = new Ensembler()
val train = ensembler.ensembling(Array(logistic1,naive),train_df,"categoryIndex","label",4,"combine_vec")
val train_result = train._1
val max = train._2
val model_result = ensembler.fit(Array(logistic1,naive),train_df)

val test_result1 = ensembler.predict(Array(logistic1,naive),model_result,test_df1,"combine_vec",max)
val test_result2 = ensembler.predict(Array(logistic1,naive),model_result,test_df2,"combine_vec",max)

val logistic = new org.apache.spark.ml.classification.LogisticRegression().setMaxIter(15).setLabelCol(
    "categoryIndex").setFeaturesCol("combine_vec").setPredictionCol("LogicCategory").setFamily("multinomial")
val logistic_model = logistic.fit(train_result)
val predicted_df1 = logistic_model.transform(test_result1)
val predicted_df2 = logistic_model.transform(test_result2)

val indexList = train_df.select("label","categoryIndex").distinct.toDF("predLabel","LogicCategory")
val result1 = predicted_df1.join(indexList,"LogicCategory")
val result2 = predicted_df2.join(indexList,"LogicCategory")

result1.select("label","predLabel").rdd.filter(x => x.getString(0).equals(x.getString(1))).count
result1.count

result2.select("label","predLabel").rdd.filter(x => x.getString(0).equals(x.getString(1))).count
result2.count

//predicted_df.select("document","label","LogicCategory").coalesce(1).write.format(
//     "org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").save("/data/etl_combine/latest_run/pred_df_df22")
indexList.coalesce(1).write.format(
     "org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").save("/data/etl_combine/latest_run/indexList_train_IB_test_golden_top15_csv")
     
//result.write.format("org.apache.spark.sql.execution.datasources.parquet.ParquetFileFormat").save("/data/etl_combine/latest_run/result_train_IB_test_golden_top15")
//result = result.select("document","label","probability","predLabel","LogicCategory")
import org.apache.spark.sql._   // Imports Row, Column, Dataframe, RDD etc.
import org.apache.spark.sql.types._  //Imports StructType, StructField etc.
var temp_res = result2.select("document","label","probability","predLabel","LogicCategory").rdd.map(x=>Row(x.get(0),x.get(1),x.get(2).toString(),x.get(3),x.get(4)))
// Construct the schema for the new df which will be made by reconverting above rdd to df
val newSchema = new StructType(
    Array(
    StructField("document",StringType,nullable = true),
    StructField("label",StringType,nullable = true),
    StructField("probability",StringType,nullable = true),
    StructField("predLabel",StringType,nullable = true),
    StructField("LogicCategory",DoubleType,nullable = true)
    )
    )
var temp_res2 = spark.createDataFrame(temp_res,newSchema)
temp_res2.coalesce(1).write.format("org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").save(
    "/data/etl_combine/latest_run/result_train_IB_test_uncat_top15_csv")

     
     
//result.select("document","predLabel","label").coalesce(1).write.format(
//    "org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").save("/data/etl_combine/latest_run/result_gold_15_categories_and_Others_new")
//train_df.select("document","correctLabel").coalesce(1).write.format(
//    "org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").save("/data/etl_combine/production_output/Run5_top50_8020/train_8020_prod/")
//test_df.select("document","correctLabel").coalesce(1).write.format(
//    "org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").save("/data/etl_combine/production_output/Run5_top50_8020/test_8020_prod/")

///////////////////////////////////////////////////////////////////////////
    /////////////////////////////////////////////////////////////////////////////////
//// Read new data
//var newdata = spark.read.format("org.apache.spark.sql.execution.datasources.parquet.ParquetFileFormat").load("/data/etl_combine/latest_run/NewlyExtractedData/")
//newdata = newdata.select("document","index","label", "title", "content", "md5String", "requestid", "concept", "final_concept")
//// Combine both
//temp11 = temp11.union(newdata)
// 


//temp11 = temp11.where("document NOT IN (SELECT document FROM goldView)")
//
//val fractions = temp11.select("label").distinct.rdd.keyBy(_.getString(0)).map(_._1).map(x=>(x,0.8)).collectAsMap.toMap
//var train_df = temp11.stat.sampleBy("label",fractions,36L)
//var test_df = temp11.except(train_df)


//def split_concepts = (final_concept: String) => {final_concept.split(",")}
//val splitConceptsUDF = udf(split_concepts)
//uncat = uncat.withColumn("final_concept_splitted", splitConceptsUDF(col("final_concept")))
//uncat = uncat.drop("final_concept").withColumnRenamed("final_concept_splitted","final_concept")

//var test_df = gold
//var train_df = temp11.where("document NOT IN (SELECT document FROM goldView)")
//var train_df = temp11.except(test_df)

// Filter for top 50 categories
//var n = 50
//var top_n = temp11.groupBy("label").count.sort($"count".desc).limit(n)
//top_n.createOrReplaceTempView("top_n_view")
//train_df = train_df.where("label IN (SELECT label from top_n_view)")
//test_df = test_df.where("label IN (SELECT label from top_n_view)")

//gold = gold.filter("label not in ('Health and Fitness_Infertility', 'Technology and Computing_Unix')")


//// Change label distribution of train_df according to the label distribution of test_df
//var tr = train_df.groupBy("label").count.sort($"count".desc).toDF("label","count_train")
//var te = test_df.groupBy("label").count.sort($"count".desc).toDF("label","count_test")
//var tr_te = tr.join(te,"label")
//tr_te = tr_te.withColumn("tr_by_test",$"count_train"/$"count_test")
//var min_factor = tr_te.agg(min("tr_by_test")).select("min(tr_by_test)").collectAsList().get(0).getDouble(0)
//min_factor = math.ceil(min_factor).toInt
//tr_te = tr_te.withColumn("count_train_required",$"count_test"*min_factor)
////counttr_te_req = tr_te.withColumn("count_required_int", tr_te("count_required").cast(IntegerType)).drop("count_required")
//tr_te = tr_te.withColumn("prob",$"count_train_required"/$"count_train")
//import org.apache.spark.sql.functions._
//train_df = train_df.join(tr_te,"label").withColumn("rand",rand()).where($"rand"<$"prob")
  
/////////////////////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////////////////////////////


// Append stratified split train-test labels to htf_out data
//var temp_train = train_df.select("document").withColumn("split_index",lit(0))
//var temp_test = test_df.select("document").withColumn("split_index",lit(1))
//var temp = temp_train.union(temp_test)    
//
//result.select("document","predLabel","label").coalesce(1).write.format(
//    "org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").save("/data/etl_combine/latest_run/result_topicfilter_gold_only_15_categories")

//**************Comment below block if not reading those fixed 3K URLS
//////////

// For reading pred_3K and excluding them from gold
//var pred_3k = spark.read.format(
//    "org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").load(
//        "/data/etl_combine/save_predicted_df_3k/part-00000-2c010a9e-7956-4b27-bc40-3507cadac4f0.csv")
//pred_3k.createOrReplaceTempView("predview")
//
//// Train on 12K and test on the 3K URLs present n the pred_3k dataframe
//var test_df = gold.where("document IN (SELECT document FROM predview)")
//var train_df = gold.where("document NOT IN (SELECT document FROM predview)")

///////////