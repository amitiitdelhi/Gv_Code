//##  Code to be run only once on any one of the media or control or user plane data to create a static list of subscriber ids ##//

// Previous Static List was saved using the code

var num_subscribers = 10000  // number of subcribers to be retained
var file_location_name = "hdfs://jiobigdataplatform/data/network/probes/controlPlane_V1/flatfiles_enc/2018-09-01" // file to be used for creation of static list
var subscriber_id_colname = "subscriber_id" // name of the field containing IMSI
var static_subscriber_list_location = "hdfs://jiobigdataplatform/user/SIJLnetwork_guavus_user/static_subscriber_list/" // location to store the static subscriber list
//Read File
//var staticList = spark.read.format("org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").option("inferSchema","true").load(file_location_name)
var staticList = spark.read.json(file_location_name)

// Select num_subscribers number of subscribers
staticList = staticList.select(subscriber_id_colname).dropDuplicates().limit(num_subscribers)
staticList.coalesce(1).write.format("org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").mode("overwrite").option("header","true").save(static_subscriber_list_location)

