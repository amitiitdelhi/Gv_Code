
//Read gold_all
var gold_all = spark.read.parquet("/data/etl_combine/gold_all")

// Combine Tier1 and Tier2 labels to form a single label
import org.apache.spark.sql.functions._
val concat_labels = udf((col1:String,col2:String)=>{col1+"_"+col2})
gold_all = gold_all.withColumn("label",concat_labels($"Tier1",$"Tier2"))
gold_all = gold_all.select("URL","label")

// Split into train(85%) and test(15%) by  sampling on labels
val fractions = gold_all.select("label").distinct.rdd.keyBy(_.getString(0)).map(_._1).map(x=>(x,0.85)).collectAsMap.toMap
var train_df = gold_all.stat.sampleBy("label",fractions,36L)
var test_df = gold_all.except(train_df)

//Read Golden data(15K) and split into 11.2K - 2.8K - 1K

var gold = spark.read.parquet("/data/etl_combine/gold")
gold = gold.filter("final_concept_count > 0")
val fractions = gold.select("correctLabel").distinct.rdd.keyBy(_.getString(0)).map(_._1).map(x=>(x,0.07)).collectAsMap.toMap
var test_df = gold.stat.sampleBy("correctLabel",fractions,36L)
var remaining_df = gold.except(test_df)
val fractions2 = remaining_df.select("correctLabel").distinct.rdd.keyBy(_.getString(0)).map(_._1).map(x=>(x,0.80)).collectAsMap.toMap
var train_df = remaining_df.stat.sampleBy("correctLabel",fractions2,36L)
var validate_df = remaining_df.except(train_df)
println("No. of URLs in test_df : ",test_df.count)
println("No. of URLs in train_df : ", train_df.count)
println("No. of URLs in validate_df : ", validate_df.count)

test_df.select("correctLabel").distinct.count
train_df.select("correctLabel").distinct.count
validate_df.select("correctLabel").distinct.count

test_df.groupBy("correctLabel").count().sort($"count".desc).show(20,false)
train_df.groupBy("correctLabel").count().sort($"count".desc).show(20,false)
validate_df.groupBy("correctLabel").count().sort($"count".desc).show(20,false)

test_df.write.parquet("/data/etl_combine/kuljain_14_1/res_test_1K_URLs")
validate_df.write.parquet("/data/etl_combine/kuljain_14_1/res_validate_2800_URLs")
train_df.write.parquet("/data/etl_combine/kuljain_14_1/res_train_11200_URLs")

test_df.select("document").coalesce(1).write.format(
    "org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","false").option("sep","\t").save("/data/etl_combine/kuljain_14_1/prod_test_1K_URLs")
remaining_df.select("document","correctLabel").coalesce(1).write.format(
    "org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","false").option("sep","\t").save("/data/etl_combine/kuljain_14_1/prod_train_14K_URLs")
