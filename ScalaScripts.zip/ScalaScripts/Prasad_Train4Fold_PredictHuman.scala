
val temp11 = spark.read.format("org.apache.spark.sql.execution.datasources.parquet.ParquetFileFormat").load("/data/etl_combine/latest_run/att_extracted_filtered")

// For human labels
var test_df = spark.read.format("org.apache.spark.sql.execution.datasources.parquet.ParquetFileFormat").load("/data/etl_combine/production_output/Run1/label_si_out")
//var human_conf_score = spark.read.format("org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option(
//    "header","true").option("sep","\t").load("/data/etl_combine/latest_run/Prasad_ConfScore_15k.txt")
//human_conf_score = human_conf_score.select("URL","Confidence_Level").toDF("document","conf_level")
//test_df = test_df.join(human_conf_score,"document")
//test_df = test_df.filter("conf_level NOT IN ('low','NA')")
test_df = test_df.drop("label_id")

var train_df = temp11.except(test_df)

var n = 50
var top_n = temp11.groupBy("label").count.sort($"count".desc).limit(n)
top_n.createOrReplaceTempView("top_n_view")
train_df = train_df.where("label IN (SELECT label from top_n_view)")
test_df = test_df.where("label IN (SELECT label from top_n_view)")

train_df.createOrReplaceTempView("trainView")
test_df.createOrReplaceTempView("testView")

train_df = train_df.where("document NOT IN (SELECT document from testView)").repartition(50)
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
import org.apache.spark.ml.feature.StringIndexer
val indexer = new StringIndexer().setInputCol("label").setOutputCol("categoryIndex")   //setHandleInvalid("keep")
train_df = indexer.fit(train_df).transform(train_df)

val hashingTF = new org.apache.spark.ml.feature.HashingTF().setInputCol("final_concept").setOutputCol("features")
val idf = new org.apache.spark.ml.feature.IDF().setInputCol(hashingTF.getOutputCol).setOutputCol("features_scaled")
val feature_pipe = new org.apache.spark.ml.Pipeline().setStages(Array(hashingTF,idf))
val feature_pipe_model = feature_pipe.fit(train_df)

test_df = feature_pipe_model.transform(test_df)
train_df = feature_pipe_model.transform(train_df)

val naive = new org.apache.spark.ml.classification.NaiveBayes().setLabelCol("categoryIndex").setFeaturesCol(
    "features_scaled").setModelType("multinomial").setPredictionCol("NaiveCategory").setProbabilityCol("NaiveProbability").setRawPredictionCol("NaiveRaw")
val logistic1 = new org.apache.spark.ml.classification.LogisticRegression().setMaxIter(15).setLabelCol(
    "categoryIndex").setFeaturesCol("features_scaled").setPredictionCol("Logic1Category").setFamily("multinomial").setRawPredictionCol("Logic1Raw").setProbabilityCol("Logic1Probability")
val ensembler = new Ensembler()
val train = ensembler.ensembling(Array(logistic1,naive),train_df,"categoryIndex","label",4,"combine_vec")
val train_result = train._1
val max = train._2

val model_result = ensembler.fit(Array(logistic1,naive),train_df)
val test_result = ensembler.predict(Array(logistic1,naive),model_result,test_df,"combine_vec",max)

val logistic = new org.apache.spark.ml.classification.LogisticRegression().setMaxIter(15).setLabelCol("categoryIndex").setFeaturesCol("combine_vec").setPredictionCol("LogicCategory").setFamily("multinomial")
val logistic_model = logistic.fit(train_result)
val predicted_df = logistic_model.transform(test_result)

val indexList = train_df.select("label","categoryIndex").distinct.toDF("predLabel","LogicCategory")
// This result variable contains the original label and predicted label for all the URLs from the test dataset 
val result = predicted_df.join(indexList,"LogicCategory")
result.select("label","predLabel").rdd.filter(x => x.getString(0).equals(x.getString(1))).count
result.count

//predicted_df.select("document","label","LogicCategory").coalesce(1).write.format(
//     "org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").save("/data/etl_combine/latest_run/pred_df_df22_confscore")
//indexList.coalesce(1).write.format(
//     "org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").save("/data/etl_combine/latest_run/indexList_df22_confscore")
//     
//     
//result.select("document","correctLabel","predLabel").coalesce(1).write.format(
//    "org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").save("/data/etl_combine/production_output/Run5_top50_8020/result_8020_prod/")
//train_df.select("document","correctLabel").coalesce(1).write.format(
//    "org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").save("/data/etl_combine/production_output/Run5_top50_8020/train_8020_prod/")
//test_df.select("document","correctLabel").coalesce(1).write.format(
//    "org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").save("/data/etl_combine/production_output/Run5_top50_8020/test_8020_prod/")
//
    