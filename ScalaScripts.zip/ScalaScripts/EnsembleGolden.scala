var train_df = spark.read.parquet("/data/etl_combine/trainData").repartition(200)
var test_df = spark.read.parquet("/data/etl_combine/testData").repartition(200)
test_df = test_df.filter("final_concept_count > 0")
train_df = train_df.filter("final_concept_count > 0")

// Combine train and test
train_df = train_df.union(test_df)

var gold = spark.read.parquet("/data/etl_combine/gold/").repartition(200)
gold = gold.filter("final_concept_count > 0")
gold.createOrReplaceTempView("goldview")

train_df = train_df.where("document NOT IN (SELECT document FROM goldview)")
train_df = train_df.repartition(200)

// Make gold dataframe the new test_df
test_df = gold.filter("label not in ('Health and Fitness_Infertility', 'Technology and Computing_Unix')")

import org.apache.spark.ml.feature.StringIndexer
val indexer = new StringIndexer().setInputCol("label").setOutputCol("categoryIndex")
train_df = indexer.setHandleInvalid("skip").fit(train_df).transform(train_df)
val hashingTF = new org.apache.spark.ml.feature.HashingTF().setInputCol("final_concept").setOutputCol("features")
val idf = new org.apache.spark.ml.feature.IDF().setInputCol(hashingTF.getOutputCol).setOutputCol("features_scaled")
val feature_pipe = new org.apache.spark.ml.Pipeline().setStages(Array(hashingTF,idf))
val feature_pipe_model = feature_pipe.fit(train_df)
test_df = feature_pipe_model.transform(test_df)
train_df = feature_pipe_model.transform(train_df)
val naive = new org.apache.spark.ml.classification.NaiveBayes().setLabelCol("categoryIndex").setFeaturesCol("features_scaled").setModelType("multinomial").setPredictionCol("NaiveCategory").setProbabilityCol("NaiveProbability").setRawPredictionCol("NaiveRaw")
val logistic1 = new org.apache.spark.ml.classification.LogisticRegression().setMaxIter(15).setLabelCol("categoryIndex").setFeaturesCol("features_scaled").setPredictionCol("Logic1Category").setFamily("multinomial").setRawPredictionCol("Logic1Raw").setProbabilityCol("Logic1Probability")
val ensembler = new Ensembler()

//Try changing the no. of folds here, try 2 folds instead of 4

//val train = ensembler.ensembling(Array(logistic1,naive),train_df,"categoryIndex",4,"combine_vec")
//val train_result = train._1
//val max = train._2

//train_result.write.parquet("/data/etl_combine/att_ensemble_train_result_parquet")
//val train_result = spark.read.parquet("/data/etl_combine/att_ensemble_train_result_parquet")
//train_result.write.parquet("/data/etl_combine/att_ensemble_train_result_parquet_4fold")

val train_result = spark.read.parquet("/data/etl_combine/att_ensemble_train_result_parquet_4fold")
val max = 339 

val model_result = ensembler.fit(Array(logistic1,naive),train_df)
val test_result = ensembler.predict(Array(logistic1,naive),model_result,test_df,"combine_vec",max)

//test_result.write.parquet("/data/etl_combine/att_ensemble_test_result_parquet")
//val test_result = spark.read.parquet("/data/etl_combine/att_ensemble_test_result_parquet")
//test_result.write.parquet("/data/etl_combine/att_ensemble_test_result_parquet_4fold")
//val test_result = spark.read.parquet("/data/etl_combine/att_ensemble_test_result_parquet")



val logistic = new org.apache.spark.ml.classification.LogisticRegression().setMaxIter(15).setLabelCol("categoryIndex").setFeaturesCol("combine_vec").setPredictionCol("LogicCategory").setFamily("multinomial")
val logistic_model = logistic.fit(train_result)
val predicted_df = logistic_model.transform(test_result)


val indexList = train_df.select("label","categoryIndex").distinct.toDF("predLabel","LogicCategory")
val result = predicted_df.join(indexList,"LogicCategory")
result.select("label","predLabel").rdd.filter(x => x.getString(0).equals(x.getString(1))).count
result.count


//result.select("document","correctLabel","predLabel","label").toDF("document","HumanLabel","IBLabel","Ensemblelabel").coalesce(1).write.format("org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").save("/data/att_gold_csv/ensemble_labels_gold_4fold")
