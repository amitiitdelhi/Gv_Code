var train = spark.read.parquet("/data/etl_combine/trainData")
var test = spark.read.parquet("/data/etl_combine/testData")
var att = train.union(test)

var gold = spark.read.format("org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option(
    "header",false).option("sep","\t").load("/data/etl_combine/gold_15K_URL_and_Label_thrshold_10.csv")
gold = gold.toDF("document","correctLabel")

var gold = spark.read.parquet("/data/etl_combine/gold")
gold = gold.select("document","correctLabel")

var temp = gold.join(att.select("document","label"),"document")

gold.count
temp.count
temp.select("correctLabel","label").rdd.filter(x => x.getString(0).equals(x.getString(1))).count


// Split att into 9 dataframes and pass those through training pipeline
var train = spark.read.parquet("/data/etl_combine/trainData")
var test = spark.read.parquet("/data/etl_combine/testData")
var att = train.union(test)

val Array(df1,df2,df3,df4,df5,df6,df7,df8,df9) = att.randomSplit(Array(0.12,0.12,0.12,0.12,0.12,0.12,0.12,0.12,0.04))

df1.select("document","label").coalesce(1).write.format(
    "org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","false").option("sep","\t").save("/data/etl_combine/att_df1/")
df2.select("document","label").coalesce(1).write.format(
    "org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","false").option("sep","\t").save("/data/etl_combine/att_df2/")
df3.select("document","label").coalesce(1).write.format(
    "org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","false").option("sep","\t").save("/data/etl_combine/att_df3/")
df4.select("document","label").coalesce(1).write.format(
    "org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","false").option("sep","\t").save("/data/etl_combine/att_df4/")
df5.select("document","label").coalesce(1).write.format(
    "org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","false").option("sep","\t").save("/data/etl_combine/att_df5/")
df6.select("document","label").coalesce(1).write.format(
    "org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","false").option("sep","\t").save("/data/etl_combine/att_df6/")
df7.select("document","label").coalesce(1).write.format(
    "org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","false").option("sep","\t").save("/data/etl_combine/att_df7/")
df8.select("document","label").coalesce(1).write.format(
    "org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","false").option("sep","\t").save("/data/etl_combine/att_df8/")
df9.select("document","label").coalesce(1).write.format(
    "org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","false").option("sep","\t").save("/data/etl_combine/att_df9/")
