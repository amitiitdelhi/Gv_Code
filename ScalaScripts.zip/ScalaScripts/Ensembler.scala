//package com.guavus.analytics.ae.classifier

import org.apache.spark.ml.{Estimator, Transformer, PipelineModel}
import org.apache.spark.sql.Row
import org.apache.spark.sql.DataFrame
import org.apache.spark.ml.classification.ProbabilisticClassifier
import org.apache.spark.ml.feature.{StringIndexer, VectorAssembler}
import org.apache.spark.sql.types.{LongType, StructField, StructType}
import org.apache.spark.sql.functions._
import org.apache.spark.mllib.regression.LabeledPoint
import org.apache.spark.mllib.linalg.SingularValueDecomposition
import org.apache.spark.ml.linalg.SparseVector
import org.apache.spark.mllib.linalg.Vectors
import org.apache.spark.rdd.RDD
import org.apache.spark.mllib.classification.ClassificationModel
import org.apache.spark.mllib.linalg.Matrix
import scala.collection.mutable

//Lav's Imports
import scala.collection.mutable.WrappedArray
import scala.reflect.runtime.universe
import org.apache.spark.annotation.DeveloperApi
import org.apache.spark.annotation.Since
import org.apache.spark.ml.PipelineModel
import org.apache.spark.ml.linalg.Vector
import org.apache.spark.mllib.evaluation.MulticlassMetrics
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.slf4j.LoggerFactory
//import com.guavus.ae.model.MLMetrics



/**
 * Created by prateek.jain on 03/04/17.
 */
class Ensembler() {

  //Zip Function: Use String Indexer to added numeric label to specific columns. In our case, documents so that each
  //record gets a unique index. Make sure no duplicate urls are present in data.

//  def zip(df: DataFrame,doc_col: String):DataFrame = {
//    val indexer = new StringIndexer().setInputCol(doc_col).setOutputCol("index")
//    val indexed = indexer.fit(df).transform(df)
//    indexed
//  }

  
  def zip(colId: String, df: DataFrame): DataFrame = {
    val sqlContext = df.sqlContext
    val indexCol = "row_index"
    val foldCol = "fold"
    import org.apache.spark.sql.functions._
    val w = Window.partitionBy(col(colId)).orderBy(col(colId).asc)
    val indexedDF = df.withColumn(indexCol, row_number.over(w))
 
    return indexedDF
  }
  
  //stratifiedKFold: Divides data in specified number of folds while balancing the category ratios
  //Creates train and test data combinations
  def stratifiedKFold(df:DataFrame,col_label: String, col_id: String, fold: Int): Array[Array[DataFrame]] ={

    val schema = df.schema
    val spark = df.sqlContext.sparkSession
    val sc = df.sqlContext.sparkContext

    def getFold: (Int => Int) = (index: Int) => {index % fold}
    val getFoldUDF = udf(getFold)

    val indexedDF = zip(col_id, df)
    val ans = indexedDF.withColumn("fold", getFoldUDF(col("row_index")))
    ans.cache()

    var result:Array[Array[DataFrame]] = Array.fill[Array[DataFrame]](fold)(Array.fill[DataFrame](2)(null))

    for(i <- 0 to fold-1){
      val test = ans.filter(ans("fold") === i)
      val train = ans.filter(!(ans("fold") === i))
      result{i}{0} = train
      result{i}{1} = test
    }

    result
  }

  //Ensembling: Implementation of ensembling technique and outputs training_result on which to train stacker model
  def ensembling(models: Array[ProbabilisticClassifier[_, _, _]],train: DataFrame,col_label: String, col_label_lav: String,fold: Int,vec_col: String): (DataFrame,Int) ={
    val schema = train.schema
    val spark = train.sqlContext.sparkSession
    val sc = train.sqlContext.sparkContext

    //Split training data in folds and create combinations of training and test data
    val skf = stratifiedKFold(train,col_label_lav,col_label,fold)

    //Train and predicts on each skf combination for each base model
    for(i <- 0 to models.size-1){
      for(j <- 0 to skf.size-1){
        val mod = models{i}.fit(skf{j}{0}).asInstanceOf[Transformer]
        skf{j}{1} = mod.transform(skf{j}{1}).repartition(100)
      }
    }

    var result_ans:DataFrame = null

    //Combines result of predicted test
    for(j <- 0 to skf.size-1){
      if(result_ans == null){
        result_ans = skf{j}{1}
      }
      else{
        result_ans = result_ans.union(skf{j}{1}).repartition(100)
      }
    }

    //calculates maximum category number in training data
    val max = train.select(col_label).distinct.rdd.map(x => x.getDouble(0)).collect.reduceLeft(_ max _).toInt

    def oneHotEncoder:(Double => org.apache.spark.ml.linalg.Vector) = (category: Double) => {
      var result = Array.fill[Double](max)(0.0)
      if(category < max) {result{category.toInt} = 1.0}
      org.apache.spark.ml.linalg.Vectors.dense(result)
    }

    val oheUDF = udf(oneHotEncoder)

    var list = Array.fill[String](models.size)("")

    //Use oneHotEncoder method to convert predicted Category into Vector
    for(i <- 0 to models.size-1){
      result_ans = result_ans.withColumn(models{i}.getPredictionCol+"Vec",oheUDF(col(models{i}.getPredictionCol)))
      list{i} = models{i}.getPredictionCol+"Vec"
    }

    //Combine all Vectors into one Vector
    val answer = assembleList(list,result_ans,vec_col)

    (answer.repartition(100),max)
  }
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  //Ensembling with RDD as output
  def ensemblingLP(models: Array[ProbabilisticClassifier[_, _, _]],train: DataFrame,col_label: String,col_label_lav: String,fold: Int,vec_col: String): RDD[LabeledPoint] ={
    val schema = train.schema
    val spark = train.sqlContext.sparkSession
    val sc = train.sqlContext.sparkContext

    val skf = stratifiedKFold(train,col_label_lav,col_label,fold)

    for(i <- 0 to models.size-1){
      for(j <- 0 to skf.size-1){
        val mod = models{i}.fit(skf{j}{0}).asInstanceOf[Transformer]
        skf{j}{1} = mod.transform(skf{j}{1}).repartition(100)
      }
    }

    var result_ans:DataFrame = null

    for(j <- 0 to skf.size-1){
        if(result_ans == null){
          result_ans = skf{j}{1}
        }
        else{
          result_ans = result_ans.union(skf{j}{1}).repartition(100)
        }
    }

    /*for(i <- 0 to models.size-1){
      skf.foreach{ x =>
        val mod = models{i}.fit(x._1).asInstanceOf[Transformer]
        val df = mod.transform(x._2)
        //println("Modeltest_"+i+":"+df.count)
        if(result{i} == null){
          result{i} = df
        }
        result{i} = result{i}.unionAll(df)
      }
    }*/

    println("Model_0"+result_ans.count)



    //final_result

    val answer = assemble(models,result_ans,vec_col)


    //println("answer"+answer.count)

    val df = answer.select(col_label,vec_col).repartition(100)
    df.cache()
    println("df"+df.count)
    val rd = df.rdd
    println("rd"+rd.count)
    val rdd = rd.map(x => LabeledPoint(x.getDouble(0),Vectors.fromML(x.getAs[SparseVector](vec_col))))
    println("rdd"+rdd.count)
    rdd.map(x => println(x.features.size))

    rdd
  }

  //Ensembling with probabilities and not Predicted Category. No need for oneHotEncoder
  def ensemblingProb(models: Array[ProbabilisticClassifier[_, _, _]],train: DataFrame,col_label: String,col_label_lav: String,fold: Int,vec_col: String): DataFrame ={
    val schema = train.schema
    val spark = train.sqlContext.sparkSession
    val sc = train.sqlContext.sparkContext

    val skf = stratifiedKFold(train,col_label_lav, col_label,fold)

    val result:Array[DataFrame] = Array.fill[DataFrame](models.size)(null)

    for(i <- 0 to models.size-1){
      for(j <- 0 to skf.size-1){
        val mod = models{i}.fit(skf{j}{0}).asInstanceOf[Transformer]
        skf{j}{1} = mod.transform(skf{j}{1})
      }
    }

    var result_ans:DataFrame = null

    for(j <- 0 to skf.size-1){
      if(result_ans == null){
        result_ans = skf{j}{1}
      }
      else{
        result_ans = result_ans.union(skf{j}{1}).repartition(100)
      }
    }

    val answer = assembleProb(models,result_ans,vec_col)

    answer
  }
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  /////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  
  //Train each base model
  def fit(models: Array[ProbabilisticClassifier[_, _, _]],train: DataFrame): Array[Transformer] = {
    val list_models:Array[Transformer] = Array.fill[Transformer](models.size)(null)
    for(i <- 0 to models.size-1){
      list_models{i} = models{i}.fit(train.repartition(100)).asInstanceOf[Transformer]
    }
    return list_models
  }

  //Combines results of each basemodel through oneHotEncoder
  def predict(models: Array[ProbabilisticClassifier[_, _, _]],tran: Array[Transformer],test: DataFrame,vec_col: String,max:Int): DataFrame ={
    val spark = test.sqlContext.sparkSession
    val sc = test.sqlContext.sparkContext

    var result = test

    for(i <- 0 to tran.size-1){
      result = tran{i}.transform(result.repartition(100))
    }

    def oneHotEncoder:(Double => org.apache.spark.ml.linalg.Vector) = (category: Double) => {
      var result = Array.fill[Double](max)(0.0)
      if(category < max) {result{category.toInt} = 1.0}
      org.apache.spark.ml.linalg.Vectors.dense(result)
    }

    val oheUDF = udf(oneHotEncoder)

    var list = Array.fill[String](models.size)("")

    for(i <- 0 to models.size-1){
      result = result.withColumn(models{i}.getPredictionCol+"Vec",oheUDF(col(models{i}.getPredictionCol)))
      list{i} = models{i}.getPredictionCol+"Vec"
    }

    val answer = assembleList(list,result,vec_col)

    answer.repartition(100)
  }

  //Combines results of each basemodel through probabilities
  def predictProb(models: Array[ProbabilisticClassifier[_, _, _]],tran: Array[Transformer],test: DataFrame,vec_col: String): DataFrame ={
    val spark = test.sqlContext.sparkSession
    val sc = test.sqlContext.sparkContext

    val result:Array[DataFrame] = Array.fill[DataFrame](tran.size)(null)

    for(i <- 0 to tran.size-1){
      val df = tran{i}.transform(test)
      if(result{i} == null){
        result{i} = spark.createDataFrame(sc.emptyRDD[Row], df.schema)
      }
      result{i} = result{i}.union(df)
    }

    var final_result = result{0}.join(result{1}.select("document",models{1}.getProbabilityCol),"document")

    if(models.size > 2) {
      for (i <- 2 to models.size - 1) {
        final_result = final_result.join(result{i}.select("document", models{i}.getProbabilityCol), "document")
      }
    }

    val answer = assembleProb(models,final_result,vec_col)

    answer
  }

  //Combines results of each basemodel through RDD
  def predictRDD(stackerModel: ClassificationModel,df: DataFrame,label:String,vec_col:String,pred_label:String): DataFrame = {
    import df.sqlContext.implicits._

    val predictionAndLabels = df.select(label, vec_col).rdd.map { x =>
      val prediction = stackerModel.predict(Vectors.fromML(x.getAs[SparseVector](vec_col)))
      (x.getString(0),prediction)
    }
    predictionAndLabels.toDF(label,pred_label)
  }

  //Assemble all probability vectors
  def assembleProb(models: Array[ProbabilisticClassifier[_, _, _]],df: DataFrame,col_label:String): DataFrame ={

    val list = models.map(m => m.getProbabilityCol)

    val assembler = new VectorAssembler()
      .setInputCols(list)
      .setOutputCol(col_label)

    val result = assembler.transform(df)

    result
  }

  //Assemble Preicted Categories into Vectors
  def assemble(models: Array[ProbabilisticClassifier[_, _, _]],df: DataFrame,col_label:String): DataFrame ={

    val list = models.map(m => m.getPredictionCol)

    val assembler = new VectorAssembler()
      .setInputCols(list)
      .setOutputCol(col_label)

    val result = assembler.transform(df)

    result
  }

  //Assemble a list of columns into Vectors
  def assembleList(list:Array[String],df: DataFrame,col_label:String): DataFrame ={

    val assembler = new VectorAssembler()
      .setInputCols(list)
      .setOutputCol(col_label)

    val result = assembler.transform(df)

    result
  }
}