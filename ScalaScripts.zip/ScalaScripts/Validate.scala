// Checking for the Hashing TF module

var labelstr = spark.read.parquet("/data/amit/url_cat/label_si_out")
var htf = spark.read.parquet("/data/amit/url_cat/htf_out")

val hashingTF = new org.apache.spark.ml.feature.HashingTF().setInputCol("final_concept").setOutputCol("features")
val idf = new org.apache.spark.ml.feature.IDF().setInputCol(hashingTF.getOutputCol).setOutputCol("features_scaled")
val feature_pipe = new org.apache.spark.ml.Pipeline().setStages(Array(hashingTF,idf))
val feature_pipe_model = feature_pipe.fit(labelstr)

var df = feature_pipe_model.transform(labelstr)
df = df.drop("features")
df.groupBy("label_id").count().sort($"count".desc).show()

df.filter($"label_id"===30.0).show()
htf.filter($"label_id"===30.0).show()

// Checking for String Indexer Module

var cfilter = spark.read.parquet("/data/amit/url_cat/cf_out")
var labelstr = spark.read.parquet("/data/amit/url_cat/label_si_out")

import org.apache.spark.ml.feature.StringIndexer
val indexer = new StringIndexer().setInputCol("label").setOutputCol("categoryIndex")
//var df = indexer.setHandleInvalid("skip").fit(train_df).transform(train_df)
var df = indexer.fit(cfilter).transform(cfilter)





// Comparing gol and gold_all dataframes
var gold = spark.read.parquet("/data/etl_combine/gold")
var gold_all = spark.read.parquet("/data/etl_combine/gold_all")


import org.apache.spark.sql.functions._
val combcol = udf((col1:String, col2:String) => {col1+"_"+col2})
gold_all = gold_all.withColumn("label",combcol($"Tier1",$"Tier2"))
