
//var gold = spark.read.parquet("/data/etl_combine/gold/").repartition(100)
var gold = spark.read.format("org.apache.spark.sql.execution.datasources.parquet.ParquetFileFormat").load("/data/etl_combine/gold/").repartition(100)
gold = gold.filter("final_concept_count > 0")
var temp = gold.groupBy("correctLabel").count.sort($"count").filter("count > 10")
temp.createOrReplaceTempView("LabelsToRetain")
gold = gold.where("correctLabel IN (SELECT correctLabel FROM LabelsToRetain)")


var gold = spark.read.format("org.apache.spark.sql.execution.datasources.parquet.ParquetFileFormat").load("/data/etl_combine/production_output/Run2/label_si_out").repartition(100)

var gold = spark.read.format("org.apache.spark.sql.execution.datasources.parquet.ParquetFileFormat").load("/data/url_cat/label_si_out").repartition(100)

gold = gold.select("document","final_concept","label").toDF("document","final_concept","correctLabel")

//**************Uncomment the below block in case you wish split golden data randomly into train and test
//////////
val fractions = gold.select("correctLabel").distinct.rdd.keyBy(_.getString(0)).map(_._1).map(x=>(x,0.8)).collectAsMap.toMap
var train_df = gold.stat.sampleBy("correctLabel",fractions,36L)
var test_df = gold.except(train_df)
//////////
import org.apache.spark.ml.feature.StringIndexer
val indexer = new StringIndexer().setInputCol("correctLabel").setOutputCol("categoryIndex")
train_df = indexer.setHandleInvalid("skip").fit(train_df).transform(train_df)
val hashingTF = new org.apache.spark.ml.feature.HashingTF().setInputCol("final_concept").setOutputCol("features")
val idf = new org.apache.spark.ml.feature.IDF().setInputCol(hashingTF.getOutputCol).setOutputCol("features_scaled")
val feature_pipe = new org.apache.spark.ml.Pipeline().setStages(Array(hashingTF,idf))
val feature_pipe_model = feature_pipe.fit(train_df)

// Run Naive Bayes
val naive = new org.apache.spark.ml.classification.NaiveBayes().setLabelCol("categoryIndex").setFeaturesCol("features_scaled").setModelType("multinomial").setPredictionCol("NaiveCategory").setProbabilityCol("NaiveProbability").setRawPredictionCol("NaiveRaw")
val naive_pipe = new org.apache.spark.ml.Pipeline().setStages(Array(feature_pipe_model,naive))
val naive_model = naive_pipe.fit(train_df)
val predicted_df = naive_model.transform(test_df)
val indexList = train_df.select("correctLabel","categoryIndex").distinct.toDF("predLabel","NaiveCategory")  //LogicCategory
val result_nb = predicted_df.join(indexList,"NaiveCategory")  //LogicCategory
var correct_nb = result_nb.select("correctLabel","predLabel").rdd.filter(x => x.getString(0).equals(x.getString(1))).count
var total_nb = result_nb.count
println("NaiveBayes Accuracy : "+1.0*correct_nb/total_nb)

// Run logistic
val logistic = new org.apache.spark.ml.classification.LogisticRegression().setMaxIter(15).setLabelCol("categoryIndex").setFeaturesCol("features_scaled").setPredictionCol(
    "LogicCategory").setFamily("multinomial").setRawPredictionCol("LogicRaw").setProbabilityCol("LogicProbability")
val logistic_pipe = new org.apache.spark.ml.Pipeline().setStages(Array(feature_pipe_model,logistic))
val logistic_model = logistic_pipe.fit(train_df)
val predicted_df = logistic_model.transform(test_df)
val indexList = train_df.select("correctLabel","categoryIndex").distinct.toDF("predLabel","LogicCategory")  //LogicCategory
val result_lr = predicted_df.join(indexList,"LogicCategory")  //LogicCategory
var corrrect_lr = result_lr.select("correctLabel","predLabel").rdd.filter(x => x.getString(0).equals(x.getString(1))).count
var total_lr = result_lr.count
println("Logistic Accuracy : "+1.0*corrrect_lr/total_lr)

var temp_lr = result_lr.select("document","correctLabel","predLabel").toDF("document","LR_correctLabel","LR_predLabel")
var temp_nb = result_nb.select("document","correctLabel","predLabel").toDF("document","NB_correctLabel","NB_predLabel")

temp_lr.join(temp_nb,"document").coalesce(1).write.format(
    "org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").save("/data/etl_combine/nb_lr_traintest_gold_prediction")

//result.select("document","correctLabel","predLabel","label").toDF(
//    "document","HumanLabel","NBLabel","IBlabel"
//    ).coalesce(1).write.format("org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").save("/data/gold_train_test_csv/nb_labels")

//**************************************************************************************************//

var gold = spark.read.format("org.apache.spark.sql.execution.datasources.parquet.ParquetFileFormat").load("/data/etl_combine/label_si_out/").repartition(100)
//gold = gold.filter("final_concept_count > 0")
//var temp = gold.groupBy("correctLabel").count.sort($"count").filter("count > 10")
//temp.createOrReplaceTempView("LabelsToRetain")
//gold = gold.where("correctLabel IN (SELECT correctLabel FROM LabelsToRetain)")
//**************Uncomment the below block in case you wish split golden data randomly into train and test
//////////
val fractions = gold.select("label").distinct.rdd.keyBy(_.getString(0)).map(_._1).map(x=>(x,0.8)).collectAsMap.toMap
var train_df = gold.stat.sampleBy("label",fractions,36L)
var test_df = gold.except(train_df)
//////////
import org.apache.spark.ml.feature.StringIndexer
val indexer = new StringIndexer().setInputCol("label").setOutputCol("categoryIndex")
train_df = indexer.setHandleInvalid("skip").fit(train_df).transform(train_df)
val hashingTF = new org.apache.spark.ml.feature.HashingTF().setInputCol("final_concept").setOutputCol("features")
val idf = new org.apache.spark.ml.feature.IDF().setInputCol(hashingTF.getOutputCol).setOutputCol("features_scaled")
val feature_pipe = new org.apache.spark.ml.Pipeline().setStages(Array(hashingTF,idf))
val feature_pipe_model = feature_pipe.fit(train_df)
// Run logistic
val logistic = new org.apache.spark.ml.classification.LogisticRegression().setMaxIter(15).setLabelCol("categoryIndex").setFeaturesCol("features_scaled").setPredictionCol(
    "LogicCategory").setFamily("multinomial").setRawPredictionCol("LogicRaw").setProbabilityCol("LogicProbability")
val logistic_pipe = new org.apache.spark.ml.Pipeline().setStages(Array(feature_pipe_model,logistic))
val logistic_model = logistic_pipe.fit(train_df)
val predicted_df = logistic_model.transform(test_df)
val indexList = train_df.select("label","categoryIndex").distinct.toDF("predLabel","LogicCategory")  //LogicCategory
val result_lr = predicted_df.join(indexList,"LogicCategory")  //LogicCategory
var corrrect_lr = result_lr.select("label","predLabel").rdd.filter(x => x.getString(0).equals(x.getString(1))).count
var total_lr = result_lr.count
println("Logistic Accuracy : "+1.0*corrrect_lr/total_lr)
// Run Naive Bayes
val naive = new org.apache.spark.ml.classification.NaiveBayes().setLabelCol("categoryIndex").setFeaturesCol("features_scaled").setModelType("multinomial").setPredictionCol("NaiveCategory").setProbabilityCol("NaiveProbability").setRawPredictionCol("NaiveRaw")
val naive_pipe = new org.apache.spark.ml.Pipeline().setStages(Array(feature_pipe_model,naive))
val naive_model = naive_pipe.fit(train_df)
val predicted_df = naive_model.transform(test_df)
val indexList = train_df.select("label","categoryIndex").distinct.toDF("predLabel","NaiveCategory")  //LogicCategory
val result_nb = predicted_df.join(indexList,"NaiveCategory")  //LogicCategory
var correct_nb = result_nb.select("label","predLabel").rdd.filter(x => x.getString(0).equals(x.getString(1))).count
var total_nb = result_nb.count
println("NaiveBayes Accuracy : "+1.0*correct_nb/total_nb)


    
    
    
    
    