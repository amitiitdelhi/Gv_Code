//##  Code to be run on all media, control and user plane files to filter data for the already saved static list of subscriber ids ##//

// Read staticList and filter DFs accordingly
var static_subscriber_list_location = "/data/JioData/static_subscriber_list/"   // location of static file having the list of subsriber ids
var folder_to_be_filtered = "/data/JioData/"   // folder containing the files to be filtered
var file_to_be_filtered = "media_planedata_2018-04-10 03_23_12 PM"  // name of the file to be filtered
var file_extension = ".csv" // extension of the file to be filtered

var output_file_location = folder_to_be_filtered+file_to_be_filtered+"_filtered/"   // location where the filtered files will be stored

file_to_be_filtered = folder_to_be_filtered + file_to_be_filtered + file_extension

var hashing_offset = 10
var subscriber_id_colname_hashed = "subscriber_id_hashed"

// Read the customer IDs from the saved static file 
var staticList = spark.read.format("org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").option("inferSchema","true").load(static_subscriber_list_location)
// Create an SQL view for these customer IDs - this View will be used for filtering data later
staticList.createOrReplaceTempView("staticListView")

// Read the data file to be filtered and filter it using the above created SQL View
var data = spark.read.format("org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").option("inferSchema","true").load(file_to_be_filtered)
data = data.where("subscriber_id IN (SELECT subscriber_id FROM staticListView)")

// Hash the subscriber IDs by adding hashing_offset to the original IDs and then save the filtered files
def hash_subscriberId : (Long=>Long) = (subscriber_id : Long) => {subscriber_id+hashing_offset.toLong}
val hash_subscriberId_udf = udf(hash_subscriberId)
data = data.withColumn(subscriber_id_colname_hashed,hash_subscriberId_udf(col("subscriber_id"))).drop("subscriber_id")
data.coalesce(1).write.format("org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").mode("overwrite").option("header","true").save(output_file_location)

// Function to list all files

import java.io.File

def getListOfFiles(dir: String):List[File] = {
    val d = new File(dir)
    if (d.exists && d.isDirectory) {
        d.listFiles.filter(_.isFile).toList
    } else {
        List[File]()
    }
}

val files = getListOfFiles("/data/JioData/")

import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.fs.Path
import org.apache.hadoop.fs.FileStatus
val fs = FileSystem.get(new Configuration())
//fs.exists(new Path("/tmp/myfile.txt"))

List files_in_hdfs = new ArrayList();
Object files[] = null;

var all_elements = fs.listStatus(new Path("/data/JioData/"))

for (i <- 0 to all_elements.length-1){
  print (i);
  if(all_elements(i).isDirectory!=true){
    print (all_elements(i).getPath)
  }
  print ("\n")
}

