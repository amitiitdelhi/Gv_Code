
//var gold = spark.read.parquet("/data/etl_combine/gold/").repartition(100)
//gold = gold.filter("label not in ('Health and Fitness_Infertility', 'Technology and Computing_Unix')")

//var gold = spark.read.format("org.apache.spark.sql.execution.datasources.parquet.ParquetFileFormat").load("/data/etl_combine/gold/").repartition(100)
//gold = gold.filter("final_concept_count > 0")
//var temp = gold.groupBy("correctLabel").count.sort($"count").filter("count > 10")
//temp.createOrReplaceTempView("LabelsToRetain")
//gold = gold.where("correctLabel IN (SELECT correctLabel FROM LabelsToRetain)")

var gold = spark.read.format("org.apache.spark.sql.execution.datasources.parquet.ParquetFileFormat").load("/data/etl_combine/gold")//.repartition(100)
gold = gold.select("document","final_concept","label").toDF("document","final_concept","correctLabel")

//////////**** Read prod gold data
//var goldprod = spark.read.format("org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("sep","\t").load("/data/etl_combine/gold_15K_URL_and_Label_thrshold_10.csv")
//goldprod = goldprod.toDF("document","correctLabel")
//goldprod.createOrReplaceTempView("goldprodView")
//gold.where("document IN (SELECT document FROM goldprodView)")

//**************Uncomment the below block in case you wish split golden data randomly into train and test
//////////

val fractions = gold.select("correctLabel").distinct.rdd.keyBy(_.getString(0)).map(_._1).map(x=>(x,0.8)).collectAsMap.toMap
var train_df = gold.stat.sampleBy("correctLabel",fractions,36L)
var test_df = gold.except(train_df)

//////////

train_df.createOrReplaceTempView("trainView")
test_df.createOrReplaceTempView("testView")
train_df.where("document IN (SELECT document from testView)").count
test_df.where("document IN (SELECT document from trainView)").count

train_df = train_df.where("document NOT IN (SELECT document from testView)")

//var n = 50
//var top_n = gold.groupBy("correctLabel").count.sort($"count".desc).limit(n)
//top_n.createOrReplaceTempView("top_n_view")
//train_df = train_df.where("correctLabel IN (SELECT correctLabel from top_n_view)")
//test_df = test_df.where("correctLabel IN (SELECT correctLabel from top_n_view)")

val labels_to_retain = List("Adult Content_UNKNOWN", "Arts and Entertainment_Television", "Arts and Entertainment_Music", "Arts and Entertainment_Celebrity Fan/Gossip",
    "Careers_Job Search","Hobbies and Interests_Freelance Writing", "Hobbies and Interests_Video & Computer Games", "News_UNKNOWN", "Real Estate_Buying/Selling Homes", "Shopping_Engines",
    "Society_Dating", "Style and Fashion_Clothing", "Sports_Football", "Technology and Computing_Internet Technology", "Technology and Computing_Web Search")
    
var modifyLabel = udf((label:String) => if(labels_to_retain.contains(label)) label else "Others")

train_df = train_df.withColumn("label_modified",modifyLabel(col("correctLabel")))
train_df = train_df.drop("correctLabel").withColumnRenamed("label_modified","label")
train_df = train_df.filter("label not in ('Others')")

test_df = test_df.withColumn("label_modified",modifyLabel(col("correctLabel")))
test_df = test_df.drop("correctLabel").withColumnRenamed("label_modified","label")



import org.apache.spark.ml.feature.StringIndexer
val indexer = new StringIndexer().setInputCol("correctLabel").setOutputCol("categoryIndex")   //setHandleInvalid("keep")
train_df = indexer.fit(train_df).transform(train_df)

val hashingTF = new org.apache.spark.ml.feature.HashingTF().setInputCol("final_concept").setOutputCol("features")
val idf = new org.apache.spark.ml.feature.IDF().setInputCol(hashingTF.getOutputCol).setOutputCol("features_scaled")
val feature_pipe = new org.apache.spark.ml.Pipeline().setStages(Array(hashingTF,idf))
val feature_pipe_model = feature_pipe.fit(train_df)

test_df = feature_pipe_model.transform(test_df)
train_df = feature_pipe_model.transform(train_df)

val naive = new org.apache.spark.ml.classification.NaiveBayes().setLabelCol("categoryIndex").setFeaturesCol(
    "features_scaled").setModelType("multinomial").setPredictionCol("NaiveCategory").setProbabilityCol("NaiveProbability").setRawPredictionCol("NaiveRaw")
val logistic1 = new org.apache.spark.ml.classification.LogisticRegression().setMaxIter(15).setLabelCol(
    "categoryIndex").setFeaturesCol("features_scaled").setPredictionCol("Logic1Category").setFamily("multinomial").setRawPredictionCol("Logic1Raw").setProbabilityCol("Logic1Probability")
val ensembler = new Ensembler()
val train = ensembler.ensembling(Array(logistic1,naive),train_df,"categoryIndex","correctLabel",4,"combine_vec")
val train_result = train._1
val max = train._2

// train_result.write.parquet("/data/etl_combine/gold_ens_4fold_save/train_result")
// train_df.write.parquet("/data/etl_combine/gold_ens_4fold_save/train_df")
// test_df.write.parquet("/data/etl_combine/gold_ens_4fold_save/test_df")
// max: Int = 289

//var train_result = spark.read.parquet("/data/etl_combine/gold_ens_4fold_save/train_result").repartition(48)
//var train_df = spark.read.parquet("/data/etl_combine/gold_ens_4fold_save/train_df").repartition(48)
//var test_df = spark.read.parquet("/data/etl_combine/gold_ens_4fold_save/test_df").repartition(48)
//var max = 289

val model_result = ensembler.fit(Array(logistic1,naive),train_df)
val test_result = ensembler.predict(Array(logistic1,naive),model_result,test_df,"combine_vec",max)

val logistic = new org.apache.spark.ml.classification.LogisticRegression().setMaxIter(15).setLabelCol("categoryIndex").setFeaturesCol("combine_vec").setPredictionCol("LogicCategory").setFamily("multinomial")
val logistic_model = logistic.fit(train_result)
val predicted_df = logistic_model.transform(test_result)


val indexList = train_df.select("correctLabel","categoryIndex").distinct.toDF("predLabel","LogicCategory")
val result = predicted_df.join(indexList,"LogicCategory")
result.select("correctLabel","predLabel").rdd.filter(x => x.getString(0).equals(x.getString(1))).count
result.count

predicted_df.select("document","correctLabel","LogicCategory").coalesce(1).write.format(
     "org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").save("/data/etl_combine/latest_run/pred_df_gold_3k")
indexList.coalesce(1).write.format(
     "org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").save("/data/etl_combine/latest_run/indexList_gold_3k")

//result.select("document","correctLabel","predLabel","label").toDF("document","HumanLabel","NBLabel","IBlabel"
//    ).coalesce(1).write.format("org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").save("/data/gold_train_test_csv/nb_labels")

//**************Comment below block if not reading those fixed 3K URLS
//////////

// For reading pred_3K and excluding them from gold
//var pred_3k = spark.read.format(
//    "org.apache.spark.sql.execution.datasources.csv.CSVFileFormat").option("header","true").load(
//        "/data/etl_combine/save_predicted_df_3k/part-00000-2c010a9e-7956-4b27-bc40-3507cadac4f0.csv")
//pred_3k.createOrReplaceTempView("predview")
//
//// Train on 12K and test on the 3K URLs present n the pred_3k dataframe
//var test_df = gold.where("document IN (SELECT document FROM predview)")
//var train_df = gold.where("document NOT IN (SELECT document FROM predview)")

///////////
