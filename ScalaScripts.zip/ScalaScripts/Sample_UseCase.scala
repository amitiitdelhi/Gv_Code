// Read data file and create train data and test data from it
var gold = spark.read.format("org.apache.spark.sql.execution.datasources.parquet.ParquetFileFormat").load("/data/etl_combine/production_output/Run3_top25/label_si_out")//.repartition(100)
gold = gold.select("document","final_concept","label").toDF("document","final_concept","correctLabel")
val fractions = gold.select("correctLabel").distinct.rdd.keyBy(_.getString(0)).map(_._1).map(x=>(x,0.80)).collectAsMap.toMap
var train_df = gold.stat.sampleBy("correctLabel",fractions,36L)
var test_df = gold.except(train_df)

// Prepare the feature computation pipeline and run it on both train and test data 
import org.apache.spark.ml.feature.StringIndexer
val indexer = new StringIndexer().setInputCol("correctLabel").setOutputCol("categoryIndex")   //setHandleInvalid("keep")
train_df = indexer.fit(train_df).transform(train_df)
val hashingTF = new org.apache.spark.ml.feature.HashingTF().setInputCol("final_concept").setOutputCol("features")
val idf = new org.apache.spark.ml.feature.IDF().setInputCol(hashingTF.getOutputCol).setOutputCol("features_scaled")
val feature_pipe = new org.apache.spark.ml.Pipeline().setStages(Array(hashingTF,idf))
val feature_pipe_model = feature_pipe.fit(train_df)
test_df = feature_pipe_model.transform(test_df)
train_df = feature_pipe_model.transform(train_df)

// Prepare the level 1 classifiers - a Naive Bayes and a Logistic Regression
val naive = new org.apache.spark.ml.classification.NaiveBayes().setLabelCol("categoryIndex").setFeaturesCol(
    "features_scaled").setModelType("multinomial").setPredictionCol("NaiveCategory").setProbabilityCol("NaiveProbability").setRawPredictionCol("NaiveRaw")
val logistic1 = new org.apache.spark.ml.classification.LogisticRegression().setMaxIter(15).setLabelCol(
    "categoryIndex").setFeaturesCol("features_scaled").setPredictionCol("Logic1Category").setFamily("multinomial").setRawPredictionCol("Logic1Raw").setProbabilityCol("Logic1Probability")
val ensembler = new Ensembler()
val train = ensembler.ensembling(Array(logistic1,naive),train_df,"categoryIndex","correctLabel",4,"combine_vec")
val train_result = train._1
val max = train._2
val model_result = ensembler.fit(Array(logistic1,naive),train_df)
val test_result = ensembler.predict(Array(logistic1,naive),model_result,test_df,"combine_vec",max)

// Prepare the level 2 classifier - a Logistic Regression
val logistic = new org.apache.spark.ml.classification.LogisticRegression().setMaxIter(15).setLabelCol("categoryIndex").setFeaturesCol("combine_vec").setPredictionCol("LogicCategory").setFamily("multinomial")
val logistic_model = logistic.fit(train_result)
val predicted_df = logistic_model.transform(test_result)
val indexList = train_df.select("correctLabel","categoryIndex").distinct.toDF("predLabel","LogicCategory")
val result = predicted_df.join(indexList,"LogicCategory")
result.select("correctLabel","predLabel").rdd.filter(x => x.getString(0).equals(x.getString(1))).count
result.count
