import pandas as pd


#######################################################################################
#*** Preprocessing (filtering noise) 
#######################################################################################
### before sampling, filter out few observations
'''
filter out the records which doesn't have enough statistical support
based column value occurance
if one value occurance in that column is less than or equal to the cutoff value, 
these kinds of observations would be treated as noise (it would go to test2)

input: dataframe, col, cutoff
if it is unsupervised learning, since event, label are from same sets, 
we would want set the related_col=label_col, to remove the less occurance value from both columns

'''
def filter_out_few_observation(df, col, related_col=None, cutoff=5):
    g = df[col].value_counts()
    im_keys = g[g>cutoff].keys()
    im_keys_dict = {}
    for key in im_keys:
        im_keys_dict[key] = True
    df.loc[:, 'im_record'] = df.loc[:, col].apply(lambda x: True if im_keys_dict.has_key(x) else False)
    df = df[df['im_record']==True]
    print "remove noise based on {}: {} observations left".format(col, len(df))
    
    # for unsupervised learning, we need deal the related_col at the same time
    # here showed two ways to deal with it: 
    # one is just removing the corresponding records, the other one is relabeled as "Noise"
    if related_col!=None:
        print df[col].nunique(), df[related_col].nunique()
        
        df.loc[:, 'im_record'] = df.loc[:, related_col].apply(lambda x: True if im_keys_dict.has_key(x) else False)
        df = df[df['im_record']==True]
        #df.loc[:, related_col] = df.apply(lambda x: "Noise" if x.im_record==False else x[related_col], axis=1)
        print "remove noise based on {}: {} observations left".format(related_col, len(df))
        print df[col].nunique(), df[related_col].nunique()
    
    return df