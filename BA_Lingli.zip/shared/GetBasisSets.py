"""
   BasisSets related classes
"""
import itertools
import pandas as pd
import numpy as np

class BasisSet(object):
    def __init__(self, event):
        self.core = event
        self.members = []
        self.members.append(event)

    def get_members(self):
        return self.members

    def add_member(self, member):
        self.members.append(member)

    def del_members(self, remove_lists):
        for event in remove_lists:
            self.members.remove(event)

class BasisSets(object):
    def __init__(self, events):
        self.events = events
        self.count = len(events)
        self.elem = []
        for event in self.events:
            self.elem.append(BasisSet(event))

    def __len__(self):
        return self.count

    def remove_elem(self, elem):
        self.elem.remove(elem)

class BS(object):
    def __init__(self, f=2):
        #print "Initialing BasisSets...\n"
        self.f = f
        self.similar_matrix = pd.DataFrame()#index=self.event_list, columns=self.event_list)

    def fit(self, label_distributions):
        events = label_distributions.keys()
        self.event_list = events
        self.label_distributions = label_distributions
        self.basis_sets = BasisSets(events)
        return self

    ### sparse matrix version for compute distance between two events
    def _similar(self, event1, event2):
        """
        d_{ij} = dL [varphi_i - varphi_j]^2 \
\le f  dL sqrt{(varphi_j * sigma_i)^2 + (varphi_i * sigma_j)^2}
        where varphi_{i} = sqrt{p(L|e_i)}, varphi_{j} = sqrt{{p(L|e_j)}}
        """
        ph1 = self.label_distributions[event1]['sqrt_mean']
        ph2 = self.label_distributions[event2]['sqrt_mean']
        sigma1 = self.label_distributions[event1]['sqrt_std']
        sigma2 = self.label_distributions[event2]['sqrt_std']
        distance = 0.5 * (ph1-ph2).power(2).sum()
        part1 = (ph2.multiply(sigma1)).power(2)
        part2 = (ph1.multiply(sigma2)).power(2)
        sigma = (part1 + part2).power(0.5).sum()
        #f = 2
        if distance <= self.f * sigma:
            return 1
        else:
            return 0

    def compute_similar_matrix(self, event1):
        #pairs = list(itertools.combinations(self.event_list,2))
        #return zip(self.event_list, [self._similar(event, event1) for event in self.event_list])
        #return [{event : self._similar(event, event1)} for event in self.event_list]
        return [self._similar(event, event1) for event in self.event_list]

    def generate(self, basis_set):
        """
        for each basis set, using event_list to generate the basis sets \
based on similarity transitivity.
        <!---
        for event in event_list:
        if event is not core element and event is similar with core event,
            find the remove_list which is not simialr with the incoming event in current basis set
            if the remove_list is None,
                add the incoming event to current basis set
            otherwise, delete the remove list elements from current basis set
        -->
        """
        for event in self.event_list:
            if event == basis_set.core or self.similar_matrix.loc[event, basis_set.core] == False:
                continue
            else:
                remove_list = [x for x in basis_set.members \
if self.similar_matrix.loc[event, x] == False]
                if len(remove_list) == 0:
                    basis_set.add_member(event)
                else:
                    basis_set.del_members(remove_list)
        return basis_set.members

    def _is_subset(self, needle, haystack):
        if len(haystack) < len(needle):
            return False
        if set(needle).issubset(set(haystack)):
            return True
        return False

    def filter_subsets(self, lists):
        """ Given list of lists, return new list of lists without subsets  """
        for needle in lists:
            if not any(self._is_subset(needle, haystack) for haystack in lists \
if needle is not haystack):
                yield needle
