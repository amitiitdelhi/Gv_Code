"""
*** Post treatment (add behavior classes as 'bs' columns)
### add 'bs' column, get weak_ss based on 'bs' column
"""
import operator
import numpy as np
import pandas as pd

def bs_as_label(train, weak_ss, event_col='event'):
    event_type_to_bs = {}
    for i in range(len(weak_ss)):
        for event in weak_ss[i]:
            event_type_to_bs[event] = i
    train['bs'] = train[event_col].apply(lambda x: event_type_to_bs[x] \
if event_type_to_bs.has_key(x) else -1)
    return train

def get_weak_ss(train, real_event_col='tuple_from', bs_col='bs'):
    num_class = train[bs_col].nunique()
    weak_ss = [None]*num_class
    groupby_bs = train[[bs_col, real_event_col]].drop_duplicates().groupby(bs_col)
    for key in groupby_bs.groups.keys():
        weak_ss[key] = groupby_bs.get_group(key)[real_event_col].values.tolist()
    return weak_ss

# used to get behavior class hierachy structure when we use recursive way
def get_weak_ss_dict(train, event_col='ss_event', bs_col='bs'):
    #num_class = train[bs_col].nunique()
    weak_ss = {}
    groupby_bs = train[[bs_col, event_col]].drop_duplicates().groupby(bs_col)
    for key in groupby_bs.groups.keys():
        weak_ss[key] = groupby_bs.get_group(key)[event_col].values.tolist()
    return weak_ss

#*** Post treatment (compute probability of label given behavior classes)
def compute_p_l_b(df_, label_col='label', bs_col='bs', truncate=10):
    p_l_b = compute_p_a_c(df_, label_col, bs_col, truncate)
    plb_df = pd.DataFrame.from_dict(p_l_b, orient='index')
    plb_df['max_L'] = plb_df.apply(np.argmax)
    plb_df['max_p'] = plb_df.apply(lambda x: np.max(x[:-1]), axis=1)
    return p_l_b, plb_df

def compute_p_a_c(df_, attr_col, bs_col, truncate):
    p_a_c = {}
    groupby_bs = df_.groupby(bs_col)
    for b_class in groupby_bs.groups.keys():
        tmp = groupby_bs.get_group(b_class)[attr_col].value_counts(normalize=True)\
.nlargest(truncate)
        p_a_c[b_class] = tmp
    return p_a_c

###### post_treatment for indicative attribute analysis after data geometry analysis
"""
###### here are the inputs ######
train : dataframe which at least including attr_cols and behavior classes belonging column
attr_cols : this is a list for attribute related columns which used to define the event
bs_col : this is the column indicating the behavior classes the observation belongs to
"""

def get_indicative_attr_for_class(train, attr_cols, bs_col='bs'):
    """
    IndAttrforClass: showed the indicative Attribute value for each behavior classes
    key is behavior classes
    value including 'allCandidateAttrs', 'max_Attrs', 'max_value', 'num_obs', 'max_value_per'
    'allCandidateAttrs': all of the Attribute values which has the key class as max_c in p_C_A
    'max_Attrs': the Attribute value has the maximum probability
     (here we compare the observation counts), it may have multiple maximum_Attrs
    'max_value': the observation number for this max_Attrs assigning to the key class
    'num_obs': total observation for the key class
    'max_value_per': the maximum probability of Attribute value given the key class
    """
    p_a_c = {}
    for col in attr_cols:
        p_a_c[col] = compute_p_a_c(train, col, bs_col, 5)
    proba_attr_behaviorclass = {}
    for b_class in train[bs_col].unique():
        proba_attr_behaviorclass[b_class] = {}
        for col in attr_cols:
            if p_a_c[col].has_key(b_class):
                proba_attr_behaviorclass[b_class][col] = p_a_c[col][b_class].to_dict()
    proba_attr_behaviorclass_df = pd.DataFrame.from_dict(proba_attr_behaviorclass, orient='index')

    p_c_a = compute_p_c_a(train, attr_cols, bs_col)
    vc_bs = train[bs_col].value_counts()
    p_c_a_df = pd.DataFrame.from_dict(p_c_a, orient='index')
    ind_attr_for_class = {}
    groupby_max_class = p_c_a_df.groupby('max_class')
    for b_class in groupby_max_class.groups.keys():
        tmp = groupby_max_class.get_group(b_class)
        max_value = tmp['max_cnt'].max()
        ind_attr_for_class[b_class] = {'allCandidateAttrs':tmp.index.tolist(), \
                               'indicative_attrs':tmp[tmp.max_cnt == max_value].index.tolist(), \
                               'max_value':max_value, 'num_obs':vc_bs[b_class]}
    ind_attr_for_class_df = pd.DataFrame.from_dict(ind_attr_for_class, orient='index')
    ind_attr_for_class_df.loc[:, 'proba_ind_attrs'] = ind_attr_for_class_df\
.apply(lambda x: x.max_value/float(x.num_obs), axis=1)

    return ind_attr_for_class_df, p_c_a_df, proba_attr_behaviorclass_df

def compute_p_c_a(train, attr_cols, bs_col):
    """
    p_c_a : probability of behavior classes given each attribute value
            where attribute value represent as col:value
    eg, attr_cols = ["node", "manager", "class", "originalseverity"]
    possible attribute value represent like "originalseverity:3.0", or "node:obb08wauswi"

    key of p_c_a is each attribute value,
    value of p_c_a include three parts 'p', 'max_c', 'max_cnt'
    'p': probability of behavior classes
    'max_class': behavior classes which has the max probability value
        (only take one class as the max class, usually, \
if there are multiple max classes, then they have really less count)
    'max_cnt': the number of observations for this attribute value which assigned to the max_class
    """
    p_c = train[bs_col].value_counts(normalize=True).to_dict()
    p_c_a = {}
    for col in attr_cols:
        print col
        train.loc[:, col] = train.loc[:, col].astype(str)
        values_list = train[col].unique().tolist()
        train.loc[:, col+'_idx'] = train.loc[:, col].apply(values_list.index)
        groupby_attr = train.groupby(col+'_idx')
        # for each attribute values, get 'p', 'max_c', 'max_cnt'
        for attr in groupby_attr.groups.keys():
            tmp_k = "{}:{}".format(col, values_list[attr])
            tmp_v_p = groupby_attr.get_group(attr)[bs_col].value_counts(normalize=True)\
.nlargest(5).to_dict()
            vc_class = groupby_attr.get_group(attr)[bs_col].value_counts()
            """
            max_class_list = vc[vc==vc.max()].index.tolist()
            if len(max_class_list)>1:
                print tmp_k, max_class_list, vc.max()
            """
            max_class = get_max_class(train, bs_col, groupby_attr, attr)
            p_c_a[tmp_k] = {'p':tmp_v_p, 'max_class': max_class, 'max_cnt':vc_class[max_class]}
    return p_c_a

def get_max_class(train, bs_col, groupby_attr, attr):
    p_c = train[bs_col].value_counts(normalize=True).to_dict()
    tmp_v_p = groupby_attr.get_group(attr)[bs_col].value_counts(normalize=True)\
.nlargest(5).to_dict()
    x_ratio = {}
    for b_class in tmp_v_p.keys():
        x_ratio[b_class] = tmp_v_p[b_class] / p_c[b_class]
    return max(x_ratio.iteritems(), key=operator.itemgetter(1))[0]
