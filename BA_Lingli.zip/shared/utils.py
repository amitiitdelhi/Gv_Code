"""
   pickle save and load file
"""
import os
import cPickle as pickle

### load and save data
def dump(wdir, fname, data):
    """
       save data into fname
    """
    if not os.path.exists(wdir):
        os.mkdir(wdir)
    with open(os.path.join(wdir, fname), 'wb') as file:
        pickle.dump(data, file, -1)

def load(wdir, fname):
    """
       load data from fname
    """
    with open(os.path.join(wdir, fname), 'rb') as file:
        data = pickle.load(file)
        #data = pd.read_pickle(file) 
    return data
