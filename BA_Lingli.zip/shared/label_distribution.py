#######################################################################################
#*** label distribution (through sampling)
"""
do sampling to get the label distribution
> * do 15 sampling with 40% percentage data to get d_poll
> * for each event, compute mean probability of label, standard deviation, \
mean square root of probability and the corresponding standard deviation

Output is a dictionary, event is the keys, value is sub-dictionary including \
{'mean': sparse.lil_matrix(mean), 'std':sparse.lil_matrix(std), \
'sqrt_mean':sparse.lil_matrix(sqrt_mean), 'sqrt_std':sparse.lil_matrix(sqrt_std)}
"""
########################################################################################
### get label distribution
from collections import Counter
import numpy as np
from scipy import sparse
from sklearn.preprocessing import StandardScaler

def get_label_distribution(train, event_col='event', label_col='label', \
supervised=True, sample_num=15, sample_percentage=0.40):
    """dataframe as input
       through sampling to get the label distribution
    """
    sample_size = len(train) * sample_percentage
    print "Sampling part..."
    print "there are {} samples, each with {} observations".format(sample_num, sample_size)

    d_poll = sampling(train, event_col, label_col, sample_num, sample_size, supervised)

    print "******************Compute label_distribution..."
    print "Here, label_distribution actually is probability of labels given event..."
    label_distribution = {}
    for key, value in d_poll.iteritems():
        label_distribution[key] = mean_std(value, sample_num)
    #print(len(label_distribution.keys()))
    return label_distribution

def sampling(df_, event, label, sample_num, sample_size, supervised):
    """dataframe as input
       do sampling, for each sample, get the probability of label given event
    """
    d_poll = {}#defaultdict(list)
    df_ = df_.reset_index()
    print "# of rows : {}".format(len(df_))
    events = df_[event].unique()
    print "# of events : {}".format(len(events))
    max_states_nf = df_[label].max() + 1

    i = 0
    for _ in range(sample_num):
        #print "sampling {} ...".format(i+1)
        rows = np.random.randint(df_.shape[0], size=sample_size)
        sampled_df = df_.ix[rows]
        d_tmp = compute_p_L(sampled_df, event, label, max_states_nf, supervised)

        for srcaddr in d_tmp.keys():
            if d_poll.has_key(srcaddr):
                d_poll[srcaddr][i] = d_tmp[srcaddr]
            else:
                d_poll[srcaddr] = sparse.lil_matrix((sample_num, max_states_nf), dtype=np.double)
                d_poll[srcaddr][i] = d_tmp[srcaddr]

        entity_not_exist = [E for E in events if not d_tmp.has_key(E)]
        for srcaddr in entity_not_exist:
            if not d_poll.has_key(srcaddr):
                d_poll[srcaddr] = sparse.lil_matrix((sample_num, max_states_nf), dtype=np.double)
        i += 1
    return d_poll

def compute_p_L(sampled_df, event, label, max_states_nf, supervised):
    """
    for each sample, groupby entity, aggregate to get the 'flow_chain' and 'chain_length', 'p_e'
    """
    df_by_event = sampled_df.groupby(event)\
.agg({'index':'count', label:lambda l:tuple(l)}).reset_index()\
.rename(columns={'index':'chain_length'}).sort_values('chain_length', ascending=False)

    df_by_event['p_L'] = apply_multi_col(df_by_event, [label, event], \
wraper_chain_to_proba, [max_states_nf, supervised])
    return df_by_event.set_index(event)['p_L'].to_dict()

def apply_multi_col(df, col_list, wraper_chain_to_proba, args=None):
    """
       apply wrapper function with or without argment
    """
    series_list = [df[c] for c in col_list]
    # The tup_lambda_func should also be expecting the order of tuples as given in col_list
    if args is None:
        return np.array([wraper_chain_to_proba(t) for t in zip(*series_list)])
    else:
        return np.array([wraper_chain_to_proba(t, args) for t in zip(*series_list)])

def wraper_chain_to_proba(df_cols, args):
    """
       wrapper function
    """
    df_label = df_cols[0]
    df_event = df_cols[1]
    max_states_nf = args[0]
    supervised = args[1]
    return chain_to_proba(df_label, max_states_nf, df_event, supervised)

def chain_to_proba(chain, max_states_nf, event, supervised):
    """
       get the probability from the label chain for one event
    """
    proba = sparse.lil_matrix((1, max_states_nf), dtype=np.double)
    if len(chain) <= 1:
        return proba
    if supervised is True:
        state_chain = [val for val in chain]
    else:
        state_chain = [val for val in chain if val != event]

    state_counts = Counter(state_chain)
    n_e = float(len(state_chain))
    for key in state_counts.keys():
        proba[0, key] = state_counts[key] / n_e
    return proba

def mean_std(distribution_sets_, sample_num):
    """
       compute ['mean', 'std', 'sqrt_mean', 'sqrt_std'] for each entity from the sampling d_poll
    """
    # for original distance function
    distribution_sets = sparse.vstack([distribution_sets_[i] for i in range(sample_num)])
    scaler = StandardScaler(with_mean=False)
    scaler.fit(distribution_sets)
    mean = scaler.mean_
    mean = normalize(mean)
    std = np.sqrt(scaler.var_ * sample_num / (sample_num-1))

    phi = distribution_sets.sqrt()
    scaler.fit(phi)
    sqrt_mean = scaler.mean_
    sqrt_mean = normalize(sqrt_mean, 2)
    sqrt_std = np.sqrt(scaler.var_ * sample_num / (sample_num-1))

    num_of_samples = distribution_sets.shape[0]
    if num_of_samples != sample_num:
        print num_of_samples
    return {'mean': sparse.lil_matrix(mean), 'std':sparse.lil_matrix(std),\
           'sqrt_mean':sparse.lil_matrix(sqrt_mean), 'sqrt_std':sparse.lil_matrix(sqrt_std)}

def normalize(vector, ord_=1):
    """
       normalized each mean value of probability
    """
    norm = np.linalg.norm(vector, ord=ord_)
    if norm == 0:
        return vector
    return vector/norm

#######################################################################################
#*** global_sigma
#*** (which showed how noise of the data)
#######################################################################################
def select_mean_std_col(dist_func):
    """
       based on dist_function to choose mean_col and std_col
    """
    if dist_func == '0':
        mean_col = 'mean'
        std_col = 'std'
    elif dist_func == '1':
        mean_col = 'sqrt_mean'
        std_col = 'sqrt_std'
    return [mean_col, std_col]

def compute_sigma(label_distribution, dist_func='1'):
    """
       compute global_sigma for reference
    """
    [mean_col, std_col] = select_mean_std_col(dist_func)
    num_of_labels = label_distribution[label_distribution.keys()[0]][std_col].get_shape()[1]
    start = False
    for key in label_distribution.keys():
        if start is False:
            tmp_sum = label_distribution[key][std_col]
            start = True
        else:
            tmp_sum = sparse.vstack([tmp_sum, label_distribution[key][std_col]])
    mean_std_err = tmp_sum.mean(axis=0)
    sigma2 = np.sum(np.power(mean_std_err, 2))
    return sigma2
