"""
*** from basis sets to strong simsets,
*** then to weak simsets (this is the final behavior classes)
"""
from collections import Counter
import numpy as np

def SimSet(basis_sets):
    """
       remove the events in the intersection area
    """
    flat_list = [member for basis_set in basis_sets for member in basis_set]
    events_counts = Counter(flat_list)

    events = events_counts.keys()
    non_ss_event = [key for key in events_counts.keys() if events_counts[key] > 1]
    ss_event = [key for key in events_counts.keys() if events_counts[key] == 1]
    #y2 = [(key, events_counts[key]) for key in events_counts.keys() if events_counts[key] > 1]

    #print "Counter for events frequency in the basis_sets: {}".format(events_counts.values())
    print "There are {} events totally".format(len(events_counts.keys()))
    print "{} events in the intersection area.".format(len(non_ss_event))
    print '\n'
    sim_set = []
    for basis_set in basis_sets:
        #print basis_set
        tmp = [x for x in basis_set if x in ss_event]
        #if len(tmp) > 0:
        sim_set.append(tmp)
    return sim_set, events, ss_event, non_ss_event

def compute_ss_centroid(label_distribution, sim_set):
    """
       compute the centroid for sim_set
    """
    res = np.zeros(label_distribution[sim_set[0]]['sqrt_mean'].get_shape()[0])
    for event in sim_set:
        res += label_distribution[event]['sqrt_mean']
    return res / float(len(sim_set))

def distance(ph1, ph2):
    """
       distance function definition
    """
    distance = 0.5 * np.sum(np.power(ph1-ph2, 2))
    return distance

def bs_to_ss(basis_sets, label_distribution):
    """
       from basis_sets to sim_sets then to weak_sim_sets
    """
    sim_sets, events, ss_event, non_ss_event = SimSet(basis_sets)

    strong_sim_sets = [ss for ss in sim_sets if len(ss) > 0]

    ###### from strong sim_sets to weak_simsets ######
    # mapping from event to basis_sets
    event2bs = {}
    for event in events:
        event2bs[event] = []

    for i in range(len(basis_sets)):
        for elem in basis_sets[i]:
            event2bs[elem].append(i)

    # compute the centroid for each strong_sim_sets
    num_ss = len(sim_sets)
    ss_centroid = {}
    for i in range(num_ss):
        if len(sim_sets[i]) > 0:
            ss_centroid[i] = compute_ss_centroid(label_distribution, sim_sets[i])

    # get the mapping from non_ss_event to strong_sim_sets
    ss_list = ss_centroid.keys()
    event2ss = {}
    events_left = []
    for event in non_ss_event:
        phi = label_distribution[event]['sqrt_mean'].toarray()
        bs_belongings = event2bs[event]
        ss_belongings = [elem for elem in bs_belongings if elem in ss_list]
        if len(ss_belongings) == 0:
            events_left.append(event)
            # assign the events_left to closest sim_sets
            dist = [distance(phi, ss_centroid[ss]) for ss in ss_list]
            event2ss[event] = ss_list[np.argmin(dist)]
        else:
            dist = [distance(phi, ss_centroid[ss_belonging]) for ss_belonging in ss_belongings]
            d_min = np.min(dist)
            event2ss[event] = ss_belongings[np.argmin(dist)]

    print "there are {} events_left : {}".format(len(events_left), events_left)

    # add intersection events(non_ss_event) back to sim_sets
    weak_ss = sim_sets
    for event, value in event2ss.iteritems():
        weak_ss[value].append(event)
    weak_ss = [ss for ss in weak_ss if len(ss) > 0]

    print "weak_sim_sets finished... and there are {} weak_simsets.".format(len(weak_ss))
    return weak_ss
