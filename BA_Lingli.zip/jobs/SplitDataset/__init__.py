import pandas as pd
import numpy as np
from distutils.util import strtobool
from sklearn.model_selection import train_test_split
from shared.utils import dump
from shared.preprocessing import filter_out_few_observation

def analyze(sc, **job_args):
    if 'label' not in job_args:
        print "using default value for 'label'=tuple_to"
        job_args['label'] = 'tuple_to'
    if 'supervised' not in job_args:
        print "using default value for 'supervised'=True"
        job_args['supervised'] = 'True'
    if 'event_cutoff' not in job_args:
        print "using default value for 'event_cutoff'=5"
        job_args['event_cutoff'] = 5
    if 'label_cutoff' not in job_args:
        print "using default value for 'label_cutoff'=5"
        job_args['label_cutoff'] = 5
        
    input_file = job_args['input_file']
    event_related_cols = job_args['event_related_cols'].split(',')
    print event_related_cols
    label = job_args['label'] 
    wdir = job_args['wdir']
    supervised = strtobool(job_args['supervised'])    
    event_cutoff = int(job_args['event_cutoff'])
    label_cutoff = int(job_args['label_cutoff'])
    
    if input_file.split('.')[-1]=='p':
        df = load(wdir, input_file)
    else:
        df = pd.read_csv(input_file)
    print "raw data shape: ", df.shape
    
    print "******************get combination of attribute columns..."
    for col in event_related_cols:
        df[col] = df[col].apply(str)    
    if len(event_related_cols) > 1:
        df['concat_attr'] = df[event_related_cols].apply(lambda x: '|'.join(x.apply(str)), axis=1)
        print df[event_related_cols+['concat_attr']][:10]
    else:
        df.loc[:, 'concat_attr'] = df[event_related_cols[0]]
    event = 'concat_attr'
    
    print "******************Do filtering to get statistical support datasets..." 
    if supervised==True:
        df_filtered = filter_out_few_observation(df, event, cutoff=event_cutoff)
        df_filtered = filter_out_few_observation(df_filtered, label, cutoff=label_cutoff)
        events = df_filtered[event].unique().tolist()
        labels = df_filtered[label].unique().tolist()
        
        print "Supervised learning : ", "{} events left, {} labels left".format(len(events), len(labels))
    else:
        ###### to_do_list: add tuple_to as label column ######
        df_filtered = filter_out_few_observation(df, event, related_col=label, cutoff=event_cutoff) 
        events = df_filtered[event].unique().tolist()
        labels = df_filtered[label].unique().tolist()
        print "'end' is in 'tuple_to' : {}".format('end' in labels)
        elunion = list(set(events) | set(labels))
        labels = events = elunion
        print "Unsupervised learning : ", "{} events left, {} labels left".format(len(events), len(labels))
    
    print "raw data : \t{} observations, {} unique events, {} unique labels ".format(len(df), df[event].nunique(), df[label].nunique())
    print "filtered data : {} observations, {} unique events, {} unique labels ".format(len(df_filtered), df_filtered[event].nunique(), df_filtered[label].nunique())
    
    ### 'event' column are the index for events, 'label' column are the index for labels 
    df_filtered.loc[:,'event'] = df_filtered.loc[:,event].apply(lambda tf: events.index(tf))
    df_filtered.loc[:,'label'] = df_filtered.loc[:,label].apply(lambda tf: labels.index(tf))
    print "finished indexing"
    test2 = df[~df.index.isin(df_filtered.index)]
    train, test1 = train_test_split(df_filtered, test_size=0.2)
    print "saving train.p test1.p test2.p ..."
    dump(wdir, 'train.p', train)
    dump(wdir, 'test1.p', test1)
    dump(wdir, 'test2.p', test2)
    
    return train, test1, test2