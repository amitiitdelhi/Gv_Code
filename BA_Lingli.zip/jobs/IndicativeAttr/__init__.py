import pandas as pd
import numpy as np
#from distutils.util import strtobool

from shared.utils import dump, load
from shared.postprocessing import get_indicative_attr_for_class, compute_p_l_b

def analyze(sc, **job_args):
    input_file = job_args['input_file']
    attr_cols = job_args['attr_cols'].split(',')
    wdir = job_args['wdir']
    print attr_cols
    
    df = load(wdir, input_file)
    
    ind_attr_for_class_df, p_c_a_df, proba_attr_behaviorclass_df = get_indicative_attr_for_class(df[attr_cols+['bs']], attr_cols, bs_col='bs')
    ind_attr_for_class_df.to_csv(wdir+'ind_attr_for_class.csv')
    p_c_a_df.to_csv(wdir+'p_c_a.csv')
    proba_attr_behaviorclass_df.to_csv(wdir+'p_a_c.csv')
    
    dump(wdir, 'ind_attr_for_class.p', ind_attr_for_class_df)
    dump(wdir, 'p_c_a.p', p_c_a_df)
    dump(wdir, 'p_a_c.p', proba_attr_behaviorclass_df)
