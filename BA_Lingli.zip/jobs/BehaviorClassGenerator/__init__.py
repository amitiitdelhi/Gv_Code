#/* from train dataset to get the behavior classes
#*/
from shared.utils import dump, load
from shared.label_distribution import get_label_distribution, compute_sigma
from shared.GetBasisSets import BS
from shared.postprocessing import bs_as_label, get_weak_ss, get_weak_ss_dict, compute_p_l_b
from shared.bs2ss import bs_to_ss
from distutils.util import strtobool

import itertools
import pandas as pd
import numpy as np


def construct_BS(sc, label_distribution):
    '''
    * Initiallization Basis sets:
    > put each event $e_{\alpha}$ in a basis set by itself: $e_{\alpha} \leftrightarrow B_{\alpha}$ where $e_{\alpha} $is the core element in this basis sets
    * compute similar matrix (n by n, where n is the number of unique events)
    * Constructing each basis set:
    > * random shuffle the event_list
    > * for each basis set, using event_list to generate the basis sets based on similarity transitivity.
    > * remove the duplicates basis sets
    > * remove subset of basis sets.
    '''
    # compute global sigma value as reference 
    # which indicates how noisy of the data for constructing data geometry purpose
    sigma = compute_sigma(label_distribution, dist_func = '1')
    print("global mean sigma value is %f" % sigma)
    
    print("Initialing BasisSets...\n")       
    BS_ = BS(f = 2).fit(label_distribution)
    
    print("Computing Similar_matrix...\n")
    
    jobs = sc.parallelize(BS_.event_list)
    tmp = jobs.map(lambda x: (x, BS_.compute_similar_matrix(x))).cache()

    sm = tmp.collect()

    similar_matrix = pd.DataFrame.from_dict(dict(sm), orient='index')
    similar_matrix.rename(columns={i:BS_.event_list[i] for i in range(len(BS_.event_list))}, inplace=True)
    
    BS_.similar_matrix = similar_matrix
        
    print("Constructing each basis set...\n")
    np.random.shuffle(BS_.event_list)
    
    elems = sc.parallelize(BS_.basis_sets.elem)
    print("%d" % elems.count())

    generate_bs = elems.map(lambda x: BS_.generate(x)).cache()
    k = generate_bs.collect()
    
    k = [sorted(elem) for elem in k]    
    k.sort()

    print("Remove the duplicates basis set...\n")
    res = list(k for k,_ in itertools.groupby(k))
    print("Remove subset of basis set...\n")
    basis_sets = list(BS_.filter_subsets(res))
    
    return basis_sets

def geometry_recursive(sc, train, n):
    '''
    get the behavior classes recursively for unsupervised learning
    take each simset (by its ID) as it were an "event" and then compute P(simset_m | simset_n) transition proabilities as though there were event transition probabilities for this next round of computing the geometry. As a result, we should find fewer behavioral classes
    '''
    global event, label, wdir, supervised
    print "\n-------------------------- recursive run {} started ------------------------".format(n)
    weak_ss = get_weak_ss(train, real_event_col=event)
    print "there are {} behavior classes".format(len(weak_ss))
    
    train['ss_event'] = train['bs']
    if supervised==False:
        session_type_to_ss = {}
        for i in range(len(weak_ss)):
            for st in weak_ss[i]:
                session_type_to_ss[st] = i
        train['ss_label'] = train[label].apply(lambda x: session_type_to_ss[x] if session_type_to_ss.has_key(x) else len(weak_ss))
    else:
        train['ss_label'] = train['label']
    
    label_distribution = get_label_distribution(train, event_col='ss_event', label_col='ss_label', supervised=supervised)
    
    print "******************Compute basis_sets..."     
    basis_sets = construct_BS(sc, label_distribution)

    print "******************From basis_sets to weak sim_sets..."
    weak_ss_ = bs_to_ss(basis_sets, label_distribution)
    train = bs_as_label(train.drop('bs', axis=1), weak_ss_, event_col='ss_event')
    
    if len(weak_ss) - len(weak_ss_) < 1:
        print "it takes {} runs to get stabilized behavior classes".format(n)
        print "------------------------ recursive run ended ----------------------------\n\n"
        return train
    else:  
        weak_ss_dict = get_weak_ss_dict(train, event_col='ss_event')
        dump(wdir+'hierarchy', 'behavior_classes_dict{}.p'.format(n), weak_ss_dict)
        return geometry_recursive(sc, train, n+1)

    
    
def analyze(sc, **job_args):
    global event, label, wdir, supervised
    
    input_file = job_args['input_file']
    wdir = job_args['wdir']
    event = job_args['event']
    label = job_args['label']
    recursive = strtobool(job_args['recursive'])
    supervised = strtobool(job_args['supervised'])
    
    ### load train dataset
    train = load(wdir, input_file)
    
    ### get label distribution from train dataset
    label_distribution = get_label_distribution(train, event_col='event', label_col='label', supervised=supervised)
    dump(wdir, 'label_distribution.p', label_distribution)
    
    ### compute basis_sets 
    print "******************Compute basis_sets..."    
    basis_sets = construct_BS(sc, label_distribution)    
    
    ### basis_sets --> strong sim_sets --> weak sim_sets (behavior classes)
    print "******************From basis_sets to weak sim_sets..."
    weak_ss = bs_to_ss(basis_sets, label_distribution)
    #dump(wdir, 'behavior_classes_wo_recursive.p', weak_ss)
            
    print "******************add behavior class label to dataframe..."
    train = bs_as_label(train, weak_ss, event_col='event')
    weak_ss_dict = get_weak_ss_dict(train, event_col=event)
    dump(wdir+'hierarchy', 'behavior_classes_dict0.p', weak_ss_dict)
    
    if recursive==True:
        #print "recursive is True"
        train = geometry_recursive(sc, train, 1)
    
    weak_ss_ = get_weak_ss(train, real_event_col=event)    
    dump(wdir, 'behavior_classes.p', weak_ss_)
    dump(wdir, 'train_w_bc.p', train)
    
    plb, plb_df = compute_p_l_b(train, label_col=label)
    dump(wdir, 'p_l_b.p', plb)
    dump(wdir, 'p_l_b_df.p', plb_df)
