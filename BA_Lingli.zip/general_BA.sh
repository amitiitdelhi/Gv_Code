#!/bin/bash

echo "The script start time is : "$(date +%x_%r)
echo " "
echo " "

### please adjust master based on the server you used
echo "*** please set the proper  master you used for paspark job, current default master=local[30]" 
master=local[30]
#master=spark://172.30.15.75:7077

input_file=$1
event_related_cols=$2
label=$3
wdir=$4
supervised=$5
recursive=$6
attr_cols=$7

### this two parmaters can be adjusted
echo "*** default event_cutoff=5, label_cutoff=5, feel free to adjust them if needed"
event_cutoff=5
label_cutoff=5

echo "****** Preprocessing: noise filtering and split Dataset into three parts (train, test1, test2)"
python main.py --job SplitDataset --job-args input_file=$input_file event_related_cols=$event_related_cols label=$label wdir=$wdir supervised=$supervised recursive=$recursive event_cutoff=$event_cutoff label_cutoff=$label_cutoff

echo " "
echo " "
echo "****** Get Behavior classes"
spark-submit --executor-memory 15G --num-executors 4 --driver-memory 40G --total-executor-cores 100 --conf spark.driver.maxResultSize=6G --master $master --py-files jobs.zip main.py --job BehaviorClassGenerator --job-args input_file=train.p event='concat_attr' label=$label wdir=$wdir supervised=$supervised recursive=$recursive
#python main.py --job BehaviorClassGenerator --job-args input_file=train.p event='concat_attr' label=$label wdir=$wdir supervised=$supervised recursive=$recursive

echo " "
echo " "
echo "****** Get indicative Attributes for behavior classes"
python main.py --job IndicativeAttr --job-args input_file=train_w_bc.p attr_cols=$attr_cols wdir=$wdir
echo " "

echo "The script end time is : " $(date +%x_%r)
